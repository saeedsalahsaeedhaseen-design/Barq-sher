package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.test.core.app.ApplicationProvider
import com.example.data.InstalledAppsRepository
import com.example.model.ChunkSizeOption
import com.example.model.FileCategory
import com.example.model.TransferFileItem
import com.example.network.P2PChunkServer
import com.example.util.Sha256Util
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import kotlin.random.Random

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun verifyAppNameAndBranding() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("برق sher", appName)
        composeTestRule.onAllNodesWithText("برق sher", substring = true).onFirst().assertIsDisplayed()
        composeTestRule.onAllNodesWithText("جميع الحقوق محفوظة © saeed", substring = true).onFirst().assertIsDisplayed()
    }

    @Test
    fun verifyAllNineNavigationTabsAndEmptySendValidation() {
        val navTabs = listOf(
            "bottom_nav_HOME",
            "bottom_nav_APPS",
            "bottom_nav_IMAGES",
            "bottom_nav_VIDEOS",
            "bottom_nav_AUDIO",
            "bottom_nav_FILES",
            "bottom_nav_SEND",
            "bottom_nav_RECEIVE",
            "bottom_nav_HISTORY"
        )

        // Verify all 9 tabs exist in the scrollable bottom navigation bar and test navigating through them
        for (tag in navTabs) {
            composeTestRule.onNodeWithTag("main_bottom_tabs_row")
                .performScrollToNode(hasTestTag(tag))
            composeTestRule.onNodeWithTag(tag).assertExists()

            if (tag == "bottom_nav_APPS") {
                composeTestRule.onNodeWithTag(tag).performClick()
                composeTestRule.waitForIdle()
                composeTestRule.onNodeWithTag("refresh_installed_apps_button").assertExists()
            } else if (tag == "bottom_nav_SEND") {
                composeTestRule.onNodeWithTag(tag).performClick()
                composeTestRule.waitForIdle()
                composeTestRule.onNodeWithTag("start_live_sending_button")
                    .performScrollTo()
                    .performClick()
                composeTestRule.waitForIdle()
                composeTestRule.onNodeWithText(
                    "الرجاء اختيار ملف واحد على الأقل من جهازك قبل بدء الإرسال",
                    substring = true
                ).assertExists()
            }
        }
    }

    @Test
    fun verifyInstalledAppsRepositoryReadsPackageManager() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val apps = InstalledAppsRepository.loadInstalledSharableApps(context, includeSystemApps = true)
        assertNotNull(apps)
    }

    @Test
    fun verifyRealMultiFileChunkedTransferAndSha256Integrity() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val tempDir = File(context.cacheDir, "p2p_real_test_${System.currentTimeMillis()}").apply { mkdirs() }
        val receiveDir = File(tempDir, "received").apply { mkdirs() }
        val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

        try {
            // Create 4 real files representing Image, Audio, Document, and multi-chunk APK
            val imgFile = File(tempDir, "camera_photo.jpg").apply {
                writeBytes(Random(42).nextBytes(24_500))
            }
            val audioFile = File(tempDir, "voice_track.mp3").apply {
                writeBytes(Random(43).nextBytes(48_200))
            }
            val docFile = File(tempDir, "project_spec.pdf").apply {
                writeBytes("%PDF-1.7 Real Document Content ".repeat(800).toByteArray())
            }
            // 180 KB APK file -> 3 chunks when using 64 KB chunk size
            val apkFile = File(tempDir, "base_release.apk").apply {
                writeBytes(Random(44).nextBytes(180 * 1024 + 321))
            }

            val chunkOption = ChunkSizeOption.CHUNK_64KB
            val chunkSizeBytes = chunkOption.bytes.toLong()
            val sourceFiles = listOf(
                Pair(imgFile, FileCategory.IMAGE),
                Pair(audioFile, FileCategory.AUDIO),
                Pair(docFile, FileCategory.DOCUMENT),
                Pair(apkFile, FileCategory.GAME_APK)
            )

            val transferItems = sourceFiles.mapIndexed { idx, (file, cat) ->
                val sha = Sha256Util.computeFileSha256(file)
                assertTrue("SHA-256 should be 64 hex chars", sha.length == 64)
                val totalChunks = ((file.length() + chunkSizeBytes - 1) / chunkSizeBytes).toInt()
                TransferFileItem(
                    id = "test_item_$idx",
                    name = file.name,
                    sizeBytes = file.length(),
                    category = cat,
                    localFile = file,
                    totalChunks = totalChunks,
                    completedChunks = 0,
                    sha256Expected = sha
                )
            }

            var isSenderReady = false
            val sessionCode = "BRQ-7788"

            val server = P2PChunkServer(
                context = context,
                scope = serverScope,
                sessionCodeProvider = { sessionCode },
                isSenderReadyProvider = { isSenderReady },
                chunkSizeProvider = { chunkOption },
                filesProvider = { transferItems },
                onChunkServed = { _, _, _ -> }
            )
            val port = server.startServer()

            try {
                // Wait briefly for server socket to bind
                Thread.sleep(150)

                // 1. Verify /api/manifest rejects connection when sender is NOT ready (HTTP 403)
                val unreadyConn = (URL("http://127.0.0.1:$port/api/manifest?code=$sessionCode").openConnection() as HttpURLConnection)
                assertEquals(403, unreadyConn.responseCode)
                unreadyConn.disconnect()

                // 2. Activate Sender Ready state, verify wrong code is still rejected (HTTP 403)
                isSenderReady = true
                val wrongCodeConn = (URL("http://127.0.0.1:$port/api/manifest?code=BRQ-0000").openConnection() as HttpURLConnection)
                assertEquals(403, wrongCodeConn.responseCode)
                wrongCodeConn.disconnect()

                // 3. Connect with valid session code and parse manifest
                val manifestConn = (URL("http://127.0.0.1:$port/api/manifest?code=$sessionCode").openConnection() as HttpURLConnection)
                assertEquals(200, manifestConn.responseCode)
                val manifestBody = manifestConn.inputStream.bufferedReader().use { it.readText() }
                manifestConn.disconnect()

                val json = JSONObject(manifestBody)
                assertEquals(sessionCode, json.getString("sessionCode"))
                val filesArray = json.getJSONArray("files")
                assertEquals(4, filesArray.length())

                // 4. Download all 4 files chunk-by-chunk (including resumable RandomAccessFile writes)
                for (i in 0 until filesArray.length()) {
                    val fObj = filesArray.getJSONObject(i)
                    val fileId = fObj.getString("id")
                    val fileName = fObj.getString("name")
                    val expectedSize = fObj.getLong("sizeBytes")
                    val expectedSha256 = fObj.getString("sha256")
                    val totalChunks = fObj.getInt("totalChunks")

                    val partFile = File(receiveDir, "$fileName.part")
                    val finalFile = File(receiveDir, fileName)

                    for (chunkIdx in 0 until totalChunks) {
                        val chunkUrl = "http://127.0.0.1:$port/api/chunk?code=$sessionCode&fileId=$fileId&chunkIndex=$chunkIdx&chunkSize=$chunkSizeBytes"
                        val chunkConn = (URL(chunkUrl).openConnection() as HttpURLConnection)
                        assertEquals(200, chunkConn.responseCode)
                        val bytes = chunkConn.inputStream.use { it.readBytes() }
                        chunkConn.disconnect()

                        // Write chunk at exact offset using RandomAccessFile (same mechanism used for Pause/Resume)
                        RandomAccessFile(partFile, "rw").use { raf ->
                            raf.seek(chunkIdx.toLong() * chunkSizeBytes)
                            raf.write(bytes)
                        }
                    }

                    assertTrue(partFile.renameTo(finalFile))
                    assertEquals("File size must match 100% for $fileName", expectedSize, finalFile.length())
                    val actualSha256 = Sha256Util.computeFileSha256(finalFile)
                    assertEquals("SHA-256 must match 100% for $fileName", expectedSha256, actualSha256)
                    assertFalse(partFile.exists())
                }
            } finally {
                server.stopServer()
            }
        } finally {
            serverScope.cancel()
            tempDir.deleteRecursively()
        }
    }
}
