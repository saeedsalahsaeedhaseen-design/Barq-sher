package com.example.model

import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import java.io.File
import java.util.Locale

enum class FileCategory(
    val arabicLabel: String,
    val badgeColorHex: Long
) {
    VIDEO("فيديو", 0xFFF43F5E),
    IMAGE("صورة", 0xFF00E5FF),
    AUDIO("صوتيات وموسيقى", 0xFFEC4899),
    GAME_APK("تطبيق APK", 0xFF10B981),
    ARCHIVE("ملف مضغوط", 0xFFF59E0B),
    DOCUMENT("مستند / ملف", 0xFF8B5CF6);

    companion object {
        fun fromFileName(name: String, mimeType: String? = null): FileCategory {
            val lower = name.lowercase(Locale.ROOT)
            val mime = mimeType?.lowercase(Locale.ROOT) ?: ""
            return when {
                lower.endsWith(".apk") || lower.endsWith(".xapk") || lower.endsWith(".apks") ||
                    lower.endsWith(".obb") || mime == "application/vnd.android.package-archive" -> GAME_APK
                lower.endsWith(".mp4") || lower.endsWith(".mkv") || lower.endsWith(".mov") ||
                    lower.endsWith(".avi") || lower.endsWith(".webm") || lower.endsWith(".3gp") ||
                    mime.startsWith("video/") -> VIDEO
                lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") ||
                    lower.endsWith(".webp") || lower.endsWith(".heic") || lower.endsWith(".gif") ||
                    lower.endsWith(".bmp") || mime.startsWith("image/") -> IMAGE
                lower.endsWith(".mp3") || lower.endsWith(".wav") || lower.endsWith(".m4a") ||
                    lower.endsWith(".aac") || lower.endsWith(".flac") || lower.endsWith(".ogg") ||
                    lower.endsWith(".opus") || mime.startsWith("audio/") -> AUDIO
                lower.endsWith(".zip") || lower.endsWith(".rar") || lower.endsWith(".7z") ||
                    lower.endsWith(".tar") || lower.endsWith(".gz") || lower.endsWith(".bz2") ||
                    mime.contains("zip") || mime.contains("rar") || mime.contains("compressed") -> ARCHIVE
                else -> DOCUMENT
            }
        }
    }
}

enum class TransferDirection(val arabicTitle: String) {
    SENDING("إرسال مباشر (P2P)"),
    RECEIVING("استلام وتحميل (P2P)")
}

enum class FileTransferStatus(val arabicLabel: String) {
    QUEUED("في قائمة الانتظار"),
    TRANSFERRING("جاري النقل بالدفعات"),
    PAUSED("متوقف مؤقتاً"),
    VERIFYING("جاري التحقق من سلامة الملف (SHA-256)"),
    COMPLETED("مكتمل وتم التحقق (SHA-256)"),
    FAILED("فشل النقل"),
    CANCELLED("تم الإلغاء")
}

enum class ChunkSizeOption(val bytes: Int, val label: String, val description: String) {
    CHUNK_64KB(64 * 1024, "64 KB (للشبكات الضعيفة)", "مناسب لـ 3G والشبكات البطيئة"),
    CHUNK_256KB(256 * 1024, "256 KB (متوازن)", "مناسب لـ 4G و Wi-Fi 2.4GHz"),
    CHUNK_512KB(512 * 1024, "512 KB (سريع)", "ممتاز للوسائط والمستندات"),
    CHUNK_1MB(1024 * 1024, "1 MB (موصى به)", "أداء عالٍ لشبكات Wi-Fi ونقاط الاتصال"),
    CHUNK_2MB(2 * 1024 * 1024, "2 MB (توربو)", "للملفات الضخمة والشبكات السريعة")
}

enum class SortOption(val arabicLabel: String) {
    DATE_DESC("الأحدث أولاً"),
    NAME_ASC("الاسم (أ - ي)"),
    SIZE_DESC("الحجم (الأكبر أولاً)"),
    SIZE_ASC("الحجم (الأصغر أولاً)")
}

enum class FilesSubTab(val arabicLabel: String) {
    DOWNLOADS("التنزيلات"),
    RECENT("الحديثة"),
    DOCUMENTS("مستندات و PDF"),
    ARCHIVES("مضغوطة ZIP/RAR"),
    APKS("ملفات APK"),
    FOLDERS("المجلدات")
}

data class InstalledAppItem(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val apkFile: File,
    val sizeBytes: Long,
    val lastUpdatedMillis: Long,
    val isSystemApp: Boolean,
    val hasSplitApks: Boolean = false,
    val splitCount: Int = 0,
    val iconBitmap: ImageBitmap? = null
) {
    val selectionKey: String
        get() = "app:$packageName"
}

data class DeviceMediaItem(
    val id: String,
    val name: String,
    val uri: Uri? = null,
    val localFile: File? = null,
    val sizeBytes: Long,
    val dateModifiedMillis: Long,
    val durationMillis: Long = 0L,
    val mimeType: String? = null,
    val bucketOrFolderName: String = "",
    val category: FileCategory,
    val thumbnailBitmap: ImageBitmap? = null
) {
    val selectionKey: String
        get() = "media:$id"
}

data class StorageFolderItem(
    val name: String,
    val path: String,
    val fileCount: Int,
    val totalBytes: Long,
    val lastModifiedMillis: Long
)

data class TransferFileItem(
    val id: String,
    val name: String,
    val sizeBytes: Long,
    val category: FileCategory,
    val uri: Uri? = null,
    val localFile: File? = null,
    val packageName: String? = null,
    val hasSplitWarning: Boolean = false,
    val totalChunks: Int,
    val completedChunks: Int = 0,
    val transferredBytes: Long = 0L,
    val currentSpeedBytesPerSec: Double = 0.0,
    val status: FileTransferStatus = FileTransferStatus.QUEUED,
    val savedPath: String? = null,
    val sha256Expected: String = "",
    val sha256Actual: String = "",
    val sha256Verified: Boolean = false,
    val errorMessage: String? = null
) {
    val progressFraction: Float
        get() = if (sizeBytes <= 0L) 0f else (transferredBytes.toFloat() / sizeBytes.toFloat()).coerceIn(0f, 1f)

    val progressPercent: Int
        get() = (progressFraction * 100f).toInt().coerceIn(0, 100)

    val currentSpeedMbps: Double
        get() = currentSpeedBytesPerSec / (1024.0 * 1024.0)
}

data class TransferHistoryRecord(
    val id: String,
    val fileName: String,
    val sizeBytes: Long,
    val category: FileCategory,
    val direction: TransferDirection,
    val status: FileTransferStatus,
    val timestampMillis: Long,
    val savedPath: String? = null,
    val sha256Hash: String = "",
    val sha256Verified: Boolean = false,
    val averageSpeedBytesPerSec: Double = 0.0,
    val peerAddress: String = "",
    val errorMessage: String? = null
)

data class DiscoveredPeerSession(
    val sessionCode: String,
    val hostIp: String,
    val port: Int,
    val deviceName: String,
    val fileCount: Int,
    val totalBytes: Long,
    val lastSeenMillis: Long
)

data class HotspotNetworkStatus(
    val localIp: String = "192.168.43.1",
    val allLocalIps: List<String> = listOf("192.168.43.1"),
    val port: Int = 8989,
    val is5GHzBand: Boolean = false,
    val frequencyMHz: Int = 2412,
    val linkSpeedMbps: Int = 144,
    val ssidOrInterface: String = "شبكة محلية متاحة",
    val networkTypeLabel: String = "Wi-Fi / نقطة اتصال محلية",
    val isServerRunning: Boolean = false
) {
    val webPortalUrl: String
        get() = "http://$localIp:$port"
}

enum class AppScreen(val arabicTabTitle: String) {
    HOME("الرئيسية"),
    APPS("التطبيقات"),
    IMAGES("الصور"),
    VIDEOS("الفيديوهات"),
    AUDIO("الصوتيات"),
    FILES("الملفات"),
    SEND("إرسال"),
    RECEIVE("استلام"),
    HISTORY("سجل النقل"),
    QR_SCANNER("مسح QR"),
    LIVE_TRANSFER("النقل الحي"),
    WEBRTC_PORTAL("بوابة الويب")
}
