package com.example.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.example.model.DeviceMediaItem
import com.example.model.FileCategory
import com.example.model.StorageFolderItem
import java.io.File

/**
 * Queries real device media and files via MediaStore, accessible storage directories,
 * and Storage Access Framework (SAF) DocumentTrees.
 */
object DeviceMediaRepository {

    fun loadImages(context: Context, maxItems: Int = 250): List<DeviceMediaItem> {
        val resolver = context.contentResolver
        val items = mutableListOf<DeviceMediaItem>()
        val projection = arrayOf(
            MediaStore.Images.Media._ID,
            MediaStore.Images.Media.DISPLAY_NAME,
            MediaStore.Images.Media.SIZE,
            MediaStore.Images.Media.DATE_MODIFIED,
            MediaStore.Images.Media.MIME_TYPE,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME
        )
        val sortOrder = "${MediaStore.Images.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)

                var count = 0
                while (cursor.moveToNext() && count < maxItems) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "IMG_$id.jpg"
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val dateSec = cursor.getLong(dateCol)
                    val mime = cursor.getString(mimeCol)
                    val bucket = if (bucketCol >= 0) cursor.getString(bucketCol) ?: "" else ""
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val thumb = if (count < 60) loadMediaThumbnail(resolver, contentUri, id, isVideo = false) else null
                    items.add(
                        DeviceMediaItem(
                            id = "img_$id",
                            name = name,
                            uri = contentUri,
                            sizeBytes = size,
                            dateModifiedMillis = dateSec * 1000L,
                            mimeType = mime,
                            bucketOrFolderName = bucket,
                            category = FileCategory.IMAGE,
                            thumbnailBitmap = thumb
                        )
                    )
                    count++
                }
            }
        } catch (_: Exception) {
        }
        return items
    }

    fun loadVideos(context: Context, maxItems: Int = 200): List<DeviceMediaItem> {
        val resolver = context.contentResolver
        val items = mutableListOf<DeviceMediaItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_MODIFIED,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )
        val sortOrder = "${MediaStore.Video.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED)
                val durCol = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                val mimeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

                var count = 0
                while (cursor.moveToNext() && count < maxItems) {
                    val id = cursor.getLong(idCol)
                    val name = cursor.getString(nameCol) ?: "VID_$id.mp4"
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val dateSec = cursor.getLong(dateCol)
                    val duration = if (durCol >= 0) cursor.getLong(durCol) else 0L
                    val mime = cursor.getString(mimeCol)
                    val bucket = if (bucketCol >= 0) cursor.getString(bucketCol) ?: "" else ""
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    val thumb = if (count < 40) loadMediaThumbnail(resolver, contentUri, id, isVideo = true) else null
                    items.add(
                        DeviceMediaItem(
                            id = "vid_$id",
                            name = name,
                            uri = contentUri,
                            sizeBytes = size,
                            dateModifiedMillis = dateSec * 1000L,
                            durationMillis = duration,
                            mimeType = mime,
                            bucketOrFolderName = bucket,
                            category = FileCategory.VIDEO,
                            thumbnailBitmap = thumb
                        )
                    )
                    count++
                }
            }
        } catch (_: Exception) {
        }
        return items
    }

    fun loadAudioFiles(context: Context, maxItems: Int = 250): List<DeviceMediaItem> {
        val resolver = context.contentResolver
        val items = mutableListOf<DeviceMediaItem>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.ARTIST
        )
        val sortOrder = "${MediaStore.Audio.Media.DATE_MODIFIED} DESC"
        try {
            resolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                null,
                null,
                sortOrder
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED)
                val durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                val mimeCol = cursor.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE)
                val artistCol = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)

                var count = 0
                while (cursor.moveToNext() && count < maxItems) {
                    val id = cursor.getLong(idCol)
                    val displayName = (if (nameCol >= 0) cursor.getString(nameCol) else null)
                        ?: (if (titleCol >= 0) cursor.getString(titleCol) else null)
                        ?: "Audio_$id.mp3"
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val dateSec = cursor.getLong(dateCol)
                    val duration = if (durCol >= 0) cursor.getLong(durCol) else 0L
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else "audio/mpeg"
                    val artist = if (artistCol >= 0) cursor.getString(artistCol) ?: "" else ""
                    val contentUri = ContentUris.withAppendedId(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        id
                    )
                    items.add(
                        DeviceMediaItem(
                            id = "aud_$id",
                            name = displayName,
                            uri = contentUri,
                            sizeBytes = size,
                            dateModifiedMillis = dateSec * 1000L,
                            durationMillis = duration,
                            mimeType = mime,
                            bucketOrFolderName = artist,
                            category = FileCategory.AUDIO
                        )
                    )
                    count++
                }
            }
        } catch (_: Exception) {
        }
        return items
    }

    /**
     * Loads general files (Documents, PDFs, ZIP/RAR Archives, APKs, Downloads, Recent files)
     * from MediaStore.Files, MediaStore.Downloads (API 29+), and accessible storage directories.
     */
    fun loadGeneralFilesAndFolders(
        context: Context
    ): Pair<List<DeviceMediaItem>, List<StorageFolderItem>> {
        val resolver = context.contentResolver
        val seenKeys = HashSet<String>()
        val allFiles = mutableListOf<DeviceMediaItem>()

        // 1. Query MediaStore.Downloads on API 29+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val dlProjection = arrayOf(
                MediaStore.Downloads._ID,
                MediaStore.Downloads.DISPLAY_NAME,
                MediaStore.Downloads.SIZE,
                MediaStore.Downloads.DATE_MODIFIED,
                MediaStore.Downloads.MIME_TYPE
            )
            try {
                resolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    dlProjection,
                    null,
                    null,
                    "${MediaStore.Downloads.DATE_MODIFIED} DESC"
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads._ID)
                    val nameCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DISPLAY_NAME)
                    val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.SIZE)
                    val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Downloads.DATE_MODIFIED)
                    val mimeCol = cursor.getColumnIndex(MediaStore.Downloads.MIME_TYPE)

                    while (cursor.moveToNext()) {
                        val id = cursor.getLong(idCol)
                        val name = cursor.getString(nameCol) ?: continue
                        val size = cursor.getLong(sizeCol)
                        if (size <= 0L) continue
                        val dateSec = cursor.getLong(dateCol)
                        val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                        val uri = ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, id)
                        val key = "$name:$size"
                        if (seenKeys.add(key)) {
                            allFiles.add(
                                DeviceMediaItem(
                                    id = "dl_$id",
                                    name = name,
                                    uri = uri,
                                    sizeBytes = size,
                                    dateModifiedMillis = dateSec * 1000L,
                                    mimeType = mime,
                                    bucketOrFolderName = "Download",
                                    category = FileCategory.fromFileName(name, mime)
                                )
                            )
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }

        // 2. Query MediaStore.Files for Documents, Archives, APKs, and Recent files
        val filesUri = MediaStore.Files.getContentUri("external")
        val fileProj = arrayOf(
            MediaStore.Files.FileColumns._ID,
            MediaStore.Files.FileColumns.DISPLAY_NAME,
            MediaStore.Files.FileColumns.SIZE,
            MediaStore.Files.FileColumns.DATE_MODIFIED,
            MediaStore.Files.FileColumns.MIME_TYPE,
            MediaStore.Images.Media.BUCKET_DISPLAY_NAME
        )
        try {
            resolver.query(
                filesUri,
                fileProj,
                "${MediaStore.Files.FileColumns.SIZE} > 0",
                null,
                "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC"
            )?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID)
                val nameCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED)
                val mimeCol = cursor.getColumnIndex(MediaStore.Files.FileColumns.MIME_TYPE)
                val bucketCol = cursor.getColumnIndex(MediaStore.Images.Media.BUCKET_DISPLAY_NAME)

                var count = 0
                while (cursor.moveToNext() && count < 300) {
                    val id = cursor.getLong(idCol)
                    val name = (if (nameCol >= 0) cursor.getString(nameCol) else null) ?: continue
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val dateSec = cursor.getLong(dateCol)
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                    val bucket = if (bucketCol >= 0) cursor.getString(bucketCol) ?: "التخزين" else "التخزين"
                    val key = "$name:$size"
                    if (seenKeys.add(key)) {
                        val contentUri = ContentUris.withAppendedId(filesUri, id)
                        allFiles.add(
                            DeviceMediaItem(
                                id = "file_$id",
                                name = name,
                                uri = contentUri,
                                sizeBytes = size,
                                dateModifiedMillis = dateSec * 1000L,
                                mimeType = mime,
                                bucketOrFolderName = bucket,
                                category = FileCategory.fromFileName(name, mime)
                            )
                        )
                        count++
                    }
                }
            }
        } catch (_: Exception) {
        }

        // 3. Scan directly accessible directories (e.g. Downloads, BarqSher, Documents, app external dirs)
        val candidateDirs = mutableListOf<File>()
        try {
            @Suppress("DEPRECATION")
            val pubDownload = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (pubDownload != null) {
                candidateDirs.add(pubDownload)
                candidateDirs.add(File(pubDownload, "BarqSher"))
            }
            @Suppress("DEPRECATION")
            val pubDocs = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
            if (pubDocs != null) candidateDirs.add(pubDocs)
        } catch (_: Exception) {
        }
        context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)?.let {
            candidateDirs.add(it)
            candidateDirs.add(File(it, "BarqSher"))
        }

        val folderSummaries = mutableListOf<StorageFolderItem>()
        for (dir in candidateDirs.distinctBy { it.absolutePath }) {
            if (!dir.exists() || !dir.isDirectory || !dir.canRead()) continue
            val children = dir.listFiles() ?: continue
            var dirTotalBytes = 0L
            var dirFileCount = 0
            for (child in children) {
                if (child.isFile && child.canRead() && child.length() > 0) {
                    dirFileCount++
                    dirTotalBytes += child.length()
                    val key = "${child.name}:${child.length()}"
                    if (seenKeys.add(key)) {
                        allFiles.add(
                            DeviceMediaItem(
                                id = "disk_${child.absolutePath.hashCode()}",
                                name = child.name,
                                localFile = child,
                                sizeBytes = child.length(),
                                dateModifiedMillis = child.lastModified(),
                                bucketOrFolderName = dir.name,
                                category = FileCategory.fromFileName(child.name)
                            )
                        )
                    }
                }
            }
            folderSummaries.add(
                StorageFolderItem(
                    name = dir.name,
                    path = dir.absolutePath,
                    fileCount = dirFileCount,
                    totalBytes = dirTotalBytes,
                    lastModifiedMillis = dir.lastModified()
                )
            )
        }

        return allFiles to folderSummaries
    }

    /**
     * Reads files inside a user-picked SAF folder (OpenDocumentTree).
     */
    fun loadFilesFromDocumentTree(context: Context, treeUri: Uri): List<DeviceMediaItem> {
        val resolver = context.contentResolver
        val result = mutableListOf<DeviceMediaItem>()
        try {
            val docId = DocumentsContract.getTreeDocumentId(treeUri)
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            val projection = arrayOf(
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED,
                DocumentsContract.Document.COLUMN_MIME_TYPE
            )
            resolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val nameCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val sizeCol = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_SIZE)
                val dateCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                val mimeCol = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE)

                while (cursor.moveToNext()) {
                    val childDocId = cursor.getString(idCol) ?: continue
                    val name = cursor.getString(nameCol) ?: continue
                    val mime = if (mimeCol >= 0) cursor.getString(mimeCol) else null
                    if (mime == DocumentsContract.Document.MIME_TYPE_DIR) continue
                    val size = cursor.getLong(sizeCol)
                    if (size <= 0L) continue
                    val lastMod = if (dateCol >= 0) cursor.getLong(dateCol) else System.currentTimeMillis()
                    val childUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childDocId)
                    result.add(
                        DeviceMediaItem(
                            id = "saf_${childUri.hashCode()}",
                            name = name,
                            uri = childUri,
                            sizeBytes = size,
                            dateModifiedMillis = lastMod,
                            mimeType = mime,
                            bucketOrFolderName = "مجلد مختار (SAF)",
                            category = FileCategory.fromFileName(name, mime)
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return result
    }

    private fun loadMediaThumbnail(
        resolver: ContentResolver,
        uri: Uri,
        mediaId: Long,
        isVideo: Boolean
    ): ImageBitmap? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                resolver.loadThumbnail(uri, Size(144, 144), null).asImageBitmap()
            } else {
                @Suppress("DEPRECATION")
                val bmp = if (isVideo) {
                    MediaStore.Video.Thumbnails.getThumbnail(
                        resolver,
                        mediaId,
                        MediaStore.Video.Thumbnails.MINI_KIND,
                        BitmapFactory.Options()
                    )
                } else {
                    MediaStore.Images.Thumbnails.getThumbnail(
                        resolver,
                        mediaId,
                        MediaStore.Images.Thumbnails.MINI_KIND,
                        BitmapFactory.Options()
                    )
                }
                bmp?.asImageBitmap()
            }
        } catch (_: Exception) {
            null
        }
    }
}
