package com.example.util

import android.content.ContentResolver
import android.net.Uri
import com.example.model.TransferFileItem
import java.io.File
import java.io.FileInputStream
import java.io.InputStream
import java.security.MessageDigest

object Sha256Util {

    /**
     * Streams a File or Content Uri in 64 KB blocks to compute its exact SHA-256 hex digest
     * without loading the entire file into memory.
     */
    fun computeSha256(resolver: ContentResolver, item: TransferFileItem): String {
        val local = item.localFile
        if (local != null && local.exists() && local.isFile) {
            return computeFileSha256(local)
        }
        val uri = item.uri ?: return ""
        return computeUriSha256(resolver, uri)
    }

    fun computeFileSha256(file: File): String {
        if (!file.exists() || !file.isFile) return ""
        return try {
            FileInputStream(file).use { fis ->
                computeStreamSha256(fis)
            }
        } catch (_: Exception) {
            ""
        }
    }

    fun computeUriSha256(resolver: ContentResolver, uri: Uri): String {
        return try {
            resolver.openInputStream(uri)?.use { stream ->
                computeStreamSha256(stream)
            } ?: ""
        } catch (_: Exception) {
            ""
        }
    }

    private fun computeStreamSha256(stream: InputStream): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buffer = ByteArray(64 * 1024)
        while (true) {
            val read = stream.read(buffer)
            if (read == -1) break
            if (read > 0) {
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
