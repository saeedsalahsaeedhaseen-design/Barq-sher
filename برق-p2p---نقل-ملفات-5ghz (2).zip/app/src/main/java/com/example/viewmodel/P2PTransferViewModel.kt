package com.example.viewmodel

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.OpenableColumns
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DeviceMediaRepository
import com.example.data.InstalledAppsRepository
import com.example.model.AppScreen
import com.example.model.ChunkSizeOption
import com.example.model.DeviceMediaItem
import com.example.model.DiscoveredPeerSession
import com.example.model.FileCategory
import com.example.model.FileTransferStatus
import com.example.model.FilesSubTab
import com.example.model.HotspotNetworkStatus
import com.example.model.InstalledAppItem
import com.example.model.SortOption
import com.example.model.StorageFolderItem
import com.example.model.TransferDirection
import com.example.model.TransferFileItem
import com.example.model.TransferHistoryRecord
import com.example.network.P2PChunkServer
import com.example.util.Sha256Util
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.random.Random

data class P2PUiState(
    val currentScreen: AppScreen = AppScreen.HOME,
    val networkStatus: HotspotNetworkStatus = HotspotNetworkStatus(),
    val connectionCode: String = "BRQ-4301",
    val enteredReceiveCode: String = "",
    val isSenderReady: Boolean = false,
    val isPreparingHashes: Boolean = false,
    val remoteHostIp: String = "",
    val remoteHostPort: Int = 8989,
    val remoteSessionCode: String = "",
    val remoteChunkSizeBytes: Int = ChunkSizeOption.CHUNK_512KB.bytes,
    val pendingIncomingFiles: List<TransferFileItem> = emptyList(),
    val showReceiveConfirmationDialog: Boolean = false,
    val isConnectingToSender: Boolean = false,
    val discoveredPeers: List<DiscoveredPeerSession> = emptyList(),
    val selectedChunkSize: ChunkSizeOption = ChunkSizeOption.CHUNK_512KB,
    val transferDirection: TransferDirection = TransferDirection.SENDING,
    val files: List<TransferFileItem> = emptyList(),
    val isTransferRunning: Boolean = false,
    val isPaused: Boolean = false,
    val liveOverallSpeedBytesPerSec: Double = 0.0,
    val peakSpeedBytesPerSec: Double = 0.0,
    val statusBannerMessage: String? = null,
    val showHotspotGuideSheet: Boolean = false,
    val connectedPeerLabel: String = "بانتظار اتصال الجهاز الآخر...",
    // Installed Apps State
    val installedApps: List<InstalledAppItem> = emptyList(),
    val isLoadingApps: Boolean = false,
    val includeSystemApps: Boolean = false,
    val appsSearchQuery: String = "",
    val selectedAppPackages: Set<String> = emptySet(),
    // Device Media & File Manager State
    val hasMediaPermissions: Boolean = false,
    val permissionDeniedMessage: String? = null,
    val isLoadingMedia: Boolean = false,
    val deviceImages: List<DeviceMediaItem> = emptyList(),
    val deviceVideos: List<DeviceMediaItem> = emptyList(),
    val deviceAudio: List<DeviceMediaItem> = emptyList(),
    val deviceGeneralFiles: List<DeviceMediaItem> = emptyList(),
    val storageFolders: List<StorageFolderItem> = emptyList(),
    val safFolderFiles: List<DeviceMediaItem> = emptyList(),
    val activeFilesSubTab: FilesSubTab = FilesSubTab.DOWNLOADS,
    val mediaSearchQuery: String = "",
    val sortOption: SortOption = SortOption.DATE_DESC,
    val selectedMediaIds: Set<String> = emptySet(),
    // Transfer History State
    val transferHistory: List<TransferHistoryRecord> = emptyList()
) {
    val totalBytes: Long
        get() = files.sumOf { it.sizeBytes }

    val transferredBytes: Long
        get() = files.sumOf { it.transferredBytes }

    val overallProgressFraction: Float
        get() = if (totalBytes <= 0L) 0f else (transferredBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)

    val totalChunksCount: Int
        get() = files.sumOf { it.totalChunks }

    val completedChunksCount: Int
        get() = files.sumOf { it.completedChunks }

    val pendingTotalBytes: Long
        get() = pendingIncomingFiles.sumOf { it.sizeBytes }

    val liveOverallSpeedMbps: Double
        get() = liveOverallSpeedBytesPerSec / (1024.0 * 1024.0)

    val peakSpeedMbps: Double
        get() = peakSpeedBytesPerSec / (1024.0 * 1024.0)

    val qrPayload: String
        get() = "BARQP2P|$connectionCode|${networkStatus.localIp}|${networkStatus.port}"

    val totalSelectedCountInManager: Int
        get() = selectedAppPackages.size + selectedMediaIds.size

    val totalSelectedBytesInManager: Long
        get() {
            val appsBytes = installedApps.filter { it.packageName in selectedAppPackages }.sumOf { it.sizeBytes }
            val allMedia = (deviceImages + deviceVideos + deviceAudio + deviceGeneralFiles + safFolderFiles)
                .distinctBy { it.id }
            val mediaBytes = allMedia.filter { it.id in selectedMediaIds }.sumOf { it.sizeBytes }
            return appsBytes + mediaBytes
        }
}

class P2PTransferViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(P2PUiState())
    val uiState: StateFlow<P2PUiState> = _uiState.asStateFlow()

    private var chunkServer: P2PChunkServer? = null
    private var activeTransferJob: Job? = null
    private val senderFileStartNanoMap = ConcurrentHashMap<String, Long>()
    private val senderFileServedBytesMap = ConcurrentHashMap<String, Long>()

    init {
        checkMediaPermissionsStatus()
        loadPersistedHistory()
        startLocalP2PServerAndInspectNetwork()
        loadInstalledApps()
        loadAllDeviceMediaAndFiles()
    }

    fun checkMediaPermissionsStatus(): Boolean {
        val ctx = getApplication<Application>().applicationContext
        val granted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_IMAGES) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
        _uiState.update { it.copy(hasMediaPermissions = granted) }
        return granted
    }

    fun onMediaPermissionsResult(results: Map<String, Boolean>) {
        val anyGranted = results.values.any { it } || checkMediaPermissionsStatus()
        _uiState.update {
            it.copy(
                hasMediaPermissions = anyGranted,
                permissionDeniedMessage = if (!anyGranted) {
                    "تم رفض صلاحية قراءة الوسائط. لا يزال بإمكانك اختيار أي ملف أو مجلد عبر متصفح ملفات النظام الآمن (SAF)."
                } else null
            )
        }
        if (anyGranted) {
            loadAllDeviceMediaAndFiles()
        }
    }

    private fun startLocalP2PServerAndInspectNetwork() {
        viewModelScope.launch(Dispatchers.IO) {
            val appContext = getApplication<Application>().applicationContext
            val server = P2PChunkServer(
                context = appContext,
                scope = viewModelScope,
                sessionCodeProvider = { _uiState.value.connectionCode },
                isSenderReadyProvider = { _uiState.value.isSenderReady },
                chunkSizeProvider = { _uiState.value.selectedChunkSize },
                filesProvider = { _uiState.value.files },
                onChunkServed = { fileId, chunkIdx, bytesCount ->
                    onRemotePeerPulledChunk(fileId, chunkIdx, bytesCount)
                },
                onPeerDiscovered = { peerSession ->
                    _uiState.update { state ->
                        val updated = (listOf(peerSession) + state.discoveredPeers.filterNot {
                            it.sessionCode.equals(peerSession.sessionCode, ignoreCase = true)
                        }).take(8)
                        state.copy(discoveredPeers = updated)
                    }
                },
                onReceiverVerifiedFile = { fileId, verified ->
                    if (verified) {
                        updateFileState(fileId) { f ->
                            f.copy(
                                status = FileTransferStatus.COMPLETED,
                                sha256Verified = true
                            )
                        }
                    }
                }
            )
            val port = server.startServer()
            chunkServer = server
            val net = P2PChunkServer.inspectNetworkStatus(appContext, port, isServerRunning = true)
            val initialCode = buildShortCodeFromIp(net.localIp)
            _uiState.update {
                it.copy(
                    networkStatus = net,
                    connectionCode = initialCode,
                    enteredReceiveCode = ""
                )
            }
        }
    }

    private fun buildShortCodeFromIp(ip: String): String {
        val parts = ip.split(".")
        val lastOctet = parts.lastOrNull()?.toIntOrNull() ?: Random.nextInt(10, 99)
        val thirdOctet = parts.getOrNull(2)?.toIntOrNull() ?: 43
        val suffix = String.format(Locale.US, "%02d%02d", thirdOctet % 100, lastOctet % 100)
        return "BRQ-$suffix"
    }

    fun refreshNetworkStatus() {
        viewModelScope.launch(Dispatchers.IO) {
            val appContext = getApplication<Application>().applicationContext
            val port = chunkServer?.boundPort ?: 8989
            val net = P2PChunkServer.inspectNetworkStatus(appContext, port, isServerRunning = true)
            val updatedCode = buildShortCodeFromIp(net.localIp)
            _uiState.update {
                it.copy(
                    networkStatus = net,
                    connectionCode = if (!it.isSenderReady) updatedCode else it.connectionCode,
                    statusBannerMessage = "تم تحديث الشبكة: ${net.localIp}:${net.port} (${net.networkTypeLabel})"
                )
            }
        }
    }

    fun regenerateConnectionCode() {
        val ip = _uiState.value.networkStatus.localIp
        val parts = ip.split(".")
        val lastOctet = parts.lastOrNull()?.toIntOrNull() ?: 1
        val thirdOctet = parts.getOrNull(2)?.toIntOrNull() ?: 43
        val newCode = String.format(Locale.US, "BRQ-%02d%02d", thirdOctet % 100, lastOctet % 100)
        _uiState.update {
            it.copy(
                connectionCode = newCode,
                statusBannerMessage = "تم تحديث كود الاتصال المباشر: $newCode (العنوان: $ip:${it.networkStatus.port})"
            )
        }
    }

    fun loadInstalledApps(includeSystem: Boolean = _uiState.value.includeSystemApps) {
        _uiState.update { it.copy(isLoadingApps = true, includeSystemApps = includeSystem) }
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>().applicationContext
            val apps = InstalledAppsRepository.loadInstalledSharableApps(ctx, includeSystem)
            withContext(Dispatchers.Main) {
                _uiState.update {
                    it.copy(
                        installedApps = apps,
                        isLoadingApps = false
                    )
                }
            }
        }
    }

    fun loadAllDeviceMediaAndFiles() {
        _uiState.update { it.copy(isLoadingMedia = true) }
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>().applicationContext
            val images = DeviceMediaRepository.loadImages(ctx)
            val videos = DeviceMediaRepository.loadVideos(ctx)
            val audio = DeviceMediaRepository.loadAudioFiles(ctx)
            val (generalFiles, folders) = DeviceMediaRepository.loadGeneralFilesAndFolders(ctx)
            withContext(Dispatchers.Main) {
                _uiState.update {
                    it.copy(
                        deviceImages = images,
                        deviceVideos = videos,
                        deviceAudio = audio,
                        deviceGeneralFiles = generalFiles,
                        storageFolders = folders,
                        isLoadingMedia = false
                    )
                }
            }
        }
    }

    fun onSafFolderPicked(treeUri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>().applicationContext
            val files = DeviceMediaRepository.loadFilesFromDocumentTree(ctx, treeUri)
            withContext(Dispatchers.Main) {
                _uiState.update {
                    it.copy(
                        safFolderFiles = files,
                        activeFilesSubTab = FilesSubTab.FOLDERS,
                        statusBannerMessage = "تم فتح المجلد وقراءة ${files.size} ملفات جاهزة للتحديد والإرسال"
                    )
                }
            }
        }
    }

    fun updateAppsSearchQuery(query: String) {
        _uiState.update { it.copy(appsSearchQuery = query) }
    }

    fun updateMediaSearchQuery(query: String) {
        _uiState.update { it.copy(mediaSearchQuery = query) }
    }

    fun setSortOption(option: SortOption) {
        _uiState.update { it.copy(sortOption = option) }
    }

    fun setActiveFilesSubTab(subTab: FilesSubTab) {
        _uiState.update { it.copy(activeFilesSubTab = subTab) }
    }

    fun toggleAppSelection(packageName: String) {
        _uiState.update { state ->
            val next = state.selectedAppPackages.toMutableSet()
            if (!next.add(packageName)) next.remove(packageName)
            state.copy(selectedAppPackages = next)
        }
    }

    fun selectAllVisibleApps(visiblePackages: List<String>) {
        _uiState.update { state ->
            state.copy(selectedAppPackages = state.selectedAppPackages + visiblePackages)
        }
    }

    fun toggleMediaSelection(mediaId: String) {
        _uiState.update { state ->
            val next = state.selectedMediaIds.toMutableSet()
            if (!next.add(mediaId)) next.remove(mediaId)
            state.copy(selectedMediaIds = next)
        }
    }

    fun selectAllVisibleMedia(visibleIds: List<String>) {
        _uiState.update { state ->
            state.copy(selectedMediaIds = state.selectedMediaIds + visibleIds)
        }
    }

    fun clearAllManagerSelections() {
        _uiState.update {
            it.copy(
                selectedAppPackages = emptySet(),
                selectedMediaIds = emptySet()
            )
        }
    }

    /**
     * Converts all selected Installed Apps and MediaStore/SAF items into TransferFileItems
     * in the Send Queue and navigates to the Send screen.
     */
    fun addManagerSelectionsToSendQueueAndGoToSend() {
        val state = _uiState.value
        val chunkBytes = state.selectedChunkSize.bytes
        val newTransferItems = mutableListOf<TransferFileItem>()

        val selectedApps = state.installedApps.filter { it.packageName in state.selectedAppPackages }
        for (app in selectedApps) {
            val safeFileName = "${app.appName.replace(Regex("[\\\\/:*?\"<>|]"), "_")}_v${app.versionName}.apk"
            val totalChunks = max(1, ((app.sizeBytes + chunkBytes - 1) / chunkBytes).toInt())
            newTransferItems.add(
                TransferFileItem(
                    id = "apk_${app.packageName.hashCode()}_${System.currentTimeMillis() % 1000}",
                    name = safeFileName,
                    sizeBytes = app.sizeBytes,
                    category = FileCategory.GAME_APK,
                    localFile = app.apkFile,
                    packageName = app.packageName,
                    hasSplitWarning = app.hasSplitApks,
                    totalChunks = totalChunks
                )
            )
        }

        val allMedia = (state.deviceImages + state.deviceVideos + state.deviceAudio +
            state.deviceGeneralFiles + state.safFolderFiles).distinctBy { it.id }
        val selectedMedia = allMedia.filter { it.id in state.selectedMediaIds }
        for (media in selectedMedia) {
            val totalChunks = max(1, ((media.sizeBytes + chunkBytes - 1) / chunkBytes).toInt())
            newTransferItems.add(
                TransferFileItem(
                    id = "m_${media.id}_${System.currentTimeMillis() % 1000}",
                    name = media.name,
                    sizeBytes = media.sizeBytes,
                    category = media.category,
                    uri = media.uri,
                    localFile = media.localFile,
                    totalChunks = totalChunks
                )
            )
        }

        if (newTransferItems.isEmpty()) {
            _uiState.update {
                it.copy(statusBannerMessage = "الرجاء اختيار تطبيق أو ملف واحد على الأقل أولاً")
            }
            return
        }

        _uiState.update { current ->
            val combined = (current.files + newTransferItems).distinctBy { "${it.name}:${it.sizeBytes}" }
            current.copy(
                files = combined,
                selectedAppPackages = emptySet(),
                selectedMediaIds = emptySet(),
                isSenderReady = false,
                currentScreen = AppScreen.SEND,
                statusBannerMessage = "تمت إضافة ${newTransferItems.size} عنصر لقائمة الإرسال. اضغط (بدء الإرسال) لتفعيل جلسة النقل."
            )
        }
    }

    fun navigateTo(screen: AppScreen) {
        if (screen == AppScreen.LIVE_TRANSFER && _uiState.value.files.isEmpty()) {
            _uiState.update {
                it.copy(statusBannerMessage = "الرجاء اختيار ملف واحد على الأقل من جهازك قبل بدء الإرسال")
            }
            return
        }
        _uiState.update { it.copy(currentScreen = screen, statusBannerMessage = null) }
    }

    fun toggleHotspotGuideSheet(show: Boolean) {
        _uiState.update { it.copy(showHotspotGuideSheet = show) }
    }

    fun setChunkSize(option: ChunkSizeOption) {
        _uiState.update { state ->
            val updatedFiles = state.files.map { file ->
                val newTotalChunks = max(1, ((file.sizeBytes + option.bytes - 1) / option.bytes).toInt())
                file.copy(
                    totalChunks = newTotalChunks,
                    completedChunks = if (file.status == FileTransferStatus.COMPLETED) newTotalChunks else 0,
                    transferredBytes = if (file.status == FileTransferStatus.COMPLETED) file.sizeBytes else 0L
                )
            }
            state.copy(
                selectedChunkSize = option,
                files = updatedFiles,
                statusBannerMessage = "تم ضبط حجم الدفعة (Chunk Size) إلى ${option.label}"
            )
        }
    }

    fun updateEnteredReceiveCode(code: String) {
        _uiState.update { it.copy(enteredReceiveCode = code) }
    }

    fun clearBannerMessage() {
        _uiState.update { it.copy(statusBannerMessage = null) }
    }

    fun addPickedUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val appContext = getApplication<Application>().applicationContext
        val resolver = appContext.contentResolver
        val chunkBytes = _uiState.value.selectedChunkSize.bytes

        val addedItems = uris.mapNotNull { uri ->
            var displayName = "ملف_مرسل_${System.currentTimeMillis() % 10000}"
            var sizeBytes = 0L
            try {
                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (cursor.moveToFirst()) {
                        if (nameIdx >= 0) {
                            displayName = cursor.getString(nameIdx) ?: displayName
                        }
                        if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) {
                            sizeBytes = cursor.getLong(sizeIdx)
                        }
                    }
                }
            } catch (_: Exception) {
            }
            if (sizeBytes <= 0L) {
                try {
                    resolver.openAssetFileDescriptor(uri, "r")?.use { afd ->
                        if (afd.length > 0) sizeBytes = afd.length
                    }
                } catch (_: Exception) {
                }
            }
            if (sizeBytes <= 0L) return@mapNotNull null

            val mime = resolver.getType(uri)
            val category = FileCategory.fromFileName(displayName, mime)
            val totalChunks = max(1, ((sizeBytes + chunkBytes - 1) / chunkBytes).toInt())

            TransferFileItem(
                id = UUID.randomUUID().toString().take(8),
                name = displayName,
                sizeBytes = sizeBytes,
                category = category,
                uri = uri,
                totalChunks = totalChunks
            )
        }

        if (addedItems.isEmpty()) {
            _uiState.update {
                it.copy(statusBannerMessage = "تعذر قراءة حجم الملف المحدد، يرجى اختيار ملف صالح من الجهاز")
            }
            return
        }

        _uiState.update { state ->
            state.copy(
                files = (state.files + addedItems).distinctBy { "${it.name}:${it.sizeBytes}" },
                isSenderReady = false,
                transferDirection = TransferDirection.SENDING,
                statusBannerMessage = "تمت إضافة ${addedItems.size} ملفات. اضغط (بدء الإرسال) لتفعيل الربط للجوال المستلم."
            )
        }
    }

    fun removeFileItem(fileId: String) {
        _uiState.update { state ->
            val remaining = state.files.filterNot { it.id == fileId }
            state.copy(
                files = remaining,
                isSenderReady = if (remaining.isEmpty()) false else state.isSenderReady
            )
        }
    }

    fun clearAllFiles() {
        activeTransferJob?.cancel()
        senderFileStartNanoMap.clear()
        senderFileServedBytesMap.clear()
        _uiState.update {
            it.copy(
                files = emptyList(),
                isSenderReady = false,
                isTransferRunning = false,
                isPaused = false,
                liveOverallSpeedBytesPerSec = 0.0
            )
        }
    }

    /**
     * Cancels the active transfer session, cleans up temporary .part files, and updates state.
     */
    fun cancelActiveTransfer() {
        activeTransferJob?.cancel()
        senderFileStartNanoMap.clear()
        senderFileServedBytesMap.clear()
        _uiState.update { state ->
            val updatedFiles = state.files.map { f ->
                if (f.status == FileTransferStatus.TRANSFERRING || f.status == FileTransferStatus.QUEUED || f.status == FileTransferStatus.PAUSED) {
                    f.copy(status = FileTransferStatus.CANCELLED, currentSpeedBytesPerSec = 0.0)
                } else f
            }
            state.copy(
                isSenderReady = false,
                isTransferRunning = false,
                isPaused = false,
                liveOverallSpeedBytesPerSec = 0.0,
                files = updatedFiles,
                connectedPeerLabel = "تم إلغاء جلسة النقل وتنظيف الموارد",
                statusBannerMessage = "تم إلغاء عملية النقل بنجاح"
            )
        }
    }

    private fun onRemotePeerPulledChunk(fileId: String, chunkIdx: Int, bytesCount: Int) {
        val nowNano = System.nanoTime()
        val startNano = senderFileStartNanoMap.getOrPut(fileId) { nowNano }
        val totalServedForFile = (senderFileServedBytesMap[fileId] ?: 0L) + bytesCount.toLong()
        senderFileServedBytesMap[fileId] = totalServedForFile

        val elapsedSec = max(0.005, (nowNano - startNano) / 1_000_000_000.0)
        val realSpeedBytesPerSec = totalServedForFile.toDouble() / elapsedSec

        var newlyCompletedItem: TransferFileItem? = null

        _uiState.update { state ->
            val updated = state.files.map { item ->
                if (item.id != fileId) item
                else {
                    val newCompleted = max(item.completedChunks, chunkIdx + 1).coerceAtMost(item.totalChunks)
                    val newBytes = minOf(item.sizeBytes, totalServedForFile)
                    val isDone = newCompleted >= item.totalChunks || newBytes >= item.sizeBytes
                    val updatedItem = item.copy(
                        completedChunks = newCompleted,
                        transferredBytes = if (isDone) item.sizeBytes else newBytes,
                        status = if (isDone) FileTransferStatus.COMPLETED else FileTransferStatus.TRANSFERRING,
                        currentSpeedBytesPerSec = realSpeedBytesPerSec,
                        sha256Verified = if (isDone) true else item.sha256Verified
                    )
                    if (isDone && item.status != FileTransferStatus.COMPLETED) {
                        newlyCompletedItem = updatedItem
                    }
                    updatedItem
                }
            }
            val allCompleted = updated.isNotEmpty() && updated.all { it.status == FileTransferStatus.COMPLETED }
            state.copy(
                files = updated,
                isTransferRunning = !allCompleted,
                connectedPeerLabel = if (allCompleted) {
                    "اكتمل إرسال جميع الملفات للمستلم بنجاح"
                } else {
                    "متصل بالجهاز المستلم • جاري إرسال الدفعات عبر الشبكة"
                },
                liveOverallSpeedBytesPerSec = if (allCompleted) 0.0 else realSpeedBytesPerSec,
                peakSpeedBytesPerSec = max(state.peakSpeedBytesPerSec, realSpeedBytesPerSec),
                statusBannerMessage = if (allCompleted) {
                    "اكتمل إرسال جميع الملفات إلى الجهاز المستلم بنجاح!"
                } else {
                    state.statusBannerMessage
                }
            )
        }

        newlyCompletedItem?.let { completed ->
            recordHistoryItem(
                item = completed,
                direction = TransferDirection.SENDING,
                peerAddress = "Receiver",
                avgSpeedBytesPerSec = realSpeedBytesPerSec
            )
        }
    }

    fun startLiveChunkedTransfer(direction: TransferDirection) {
        if (_uiState.value.files.isEmpty()) {
            _uiState.update {
                it.copy(
                    statusBannerMessage = "الرجاء اختيار ملف واحد على الأقل من جهازك قبل بدء الإرسال"
                )
            }
            return
        }

        activeTransferJob?.cancel()
        senderFileStartNanoMap.clear()
        senderFileServedBytesMap.clear()

        if (direction == TransferDirection.SENDING) {
            val chunkBytes = _uiState.value.selectedChunkSize.bytes
            _uiState.update { state ->
                val resetFiles = state.files.map { f ->
                    val totalChunks = max(1, ((f.sizeBytes + chunkBytes - 1) / chunkBytes).toInt())
                    f.copy(
                        totalChunks = totalChunks,
                        completedChunks = 0,
                        transferredBytes = 0L,
                        currentSpeedBytesPerSec = 0.0,
                        status = FileTransferStatus.QUEUED
                    )
                }
                state.copy(
                    currentScreen = AppScreen.LIVE_TRANSFER,
                    transferDirection = TransferDirection.SENDING,
                    isSenderReady = true,
                    isPreparingHashes = true,
                    files = resetFiles,
                    isTransferRunning = true,
                    isPaused = false,
                    liveOverallSpeedBytesPerSec = 0.0,
                    connectedPeerLabel = "جاري حساب البصمة الرقمية SHA-256 وتفعيل جلسة الإرسال (${state.connectionCode})...",
                    statusBannerMessage = "تم تفعيل وضع الإرسال! أدخل الكود (${state.connectionCode}) أو امسح رمز QR من الجهاز الثاني."
                )
            }

            // Compute streaming SHA-256 hashes in background and broadcast UDP presence
            viewModelScope.launch(Dispatchers.IO) {
                val resolver = getApplication<Application>().contentResolver
                val currentFiles = _uiState.value.files
                for (item in currentFiles) {
                    if (!isActive) break
                    if (item.sha256Expected.isBlank()) {
                        val sha = Sha256Util.computeSha256(resolver, item)
                        updateFileState(item.id) { it.copy(sha256Expected = sha) }
                    }
                }
                chunkServer?.broadcastSenderPresence()
                withContext(Dispatchers.Main) {
                    _uiState.update { state ->
                        state.copy(
                            isPreparingHashes = false,
                            connectedPeerLabel = "بانتظار اتصال الجهاز المستلم بالكود (${state.connectionCode}) أو العنوان (${state.networkStatus.localIp}:${state.networkStatus.port})..."
                        )
                    }
                }
            }
            return
        }

        // RECEIVING direction: pull real chunks over network from remoteHostIp:remoteHostPort
        _uiState.update { state ->
            val resetFiles = state.files.map { f ->
                // Preserve completedChunks if resuming a paused/interrupted file
                if (f.completedChunks in 1 until f.totalChunks) {
                    f.copy(status = FileTransferStatus.QUEUED, currentSpeedBytesPerSec = 0.0)
                } else {
                    f.copy(
                        completedChunks = 0,
                        transferredBytes = 0L,
                        currentSpeedBytesPerSec = 0.0,
                        status = FileTransferStatus.QUEUED
                    )
                }
            }
            state.copy(
                currentScreen = AppScreen.LIVE_TRANSFER,
                transferDirection = TransferDirection.RECEIVING,
                files = resetFiles,
                isTransferRunning = true,
                isPaused = false,
                liveOverallSpeedBytesPerSec = 0.0,
                connectedPeerLabel = "متصل بالمرسل (${state.remoteHostIp}:${state.remoteHostPort} • ${state.remoteSessionCode})"
            )
        }

        activeTransferJob = viewModelScope.launch(Dispatchers.IO) {
            val appContext = getApplication<Application>().applicationContext
            val hostIp = _uiState.value.remoteHostIp
            val hostPort = _uiState.value.remoteHostPort
            val sessionCode = _uiState.value.remoteSessionCode
            val chunkSizeBytes = _uiState.value.remoteChunkSizeBytes

            val downloadDir = resolveBarqSherDownloadsDir(appContext)
            val fileIds = _uiState.value.files.map { it.id }
            var anyFailed = false

            for (fileId in fileIds) {
                if (!isActive) break
                val initialItem = _uiState.value.files.find { it.id == fileId } ?: continue
                if (initialItem.status == FileTransferStatus.COMPLETED) continue

                val totalChunks = max(1, initialItem.totalChunks)
                val tempPartFile = File(downloadDir, "${initialItem.name}.part")
                val finalOutFile = File(downloadDir, initialItem.name)

                updateFileState(fileId) {
                    it.copy(status = FileTransferStatus.TRANSFERRING, errorMessage = null)
                }

                val startChunkIdx = initialItem.completedChunks.coerceIn(0, totalChunks - 1)
                var transferredForFile = startChunkIdx.toLong() * chunkSizeBytes.toLong()
                val fileStartNano = System.nanoTime()
                var bytesDownloadedThisSession = 0L

                try {
                    RandomAccessFile(tempPartFile, "rw").use { raf ->
                        val ioBuffer = ByteArray(64 * 1024)
                        for (chunkIndex in startChunkIdx until totalChunks) {
                            while (_uiState.value.isPaused && isActive) {
                                delay(120)
                            }
                            if (!isActive) throw CancellationException("Transfer cancelled")

                            val chunkOffset = chunkIndex.toLong() * chunkSizeBytes.toLong()
                            raf.seek(chunkOffset)

                            val encodedFileId = URLEncoder.encode(initialItem.id, "UTF-8")
                            val encodedCode = URLEncoder.encode(sessionCode, "UTF-8")
                            val chunkUrl = URL(
                                "http://$hostIp:$hostPort/api/chunk?fileId=$encodedFileId&chunkIndex=$chunkIndex&chunkSize=$chunkSizeBytes&code=$encodedCode"
                            )

                            // Retry up to 3 times per chunk for transient network hiccups on slow/mobile networks
                            var attempt = 0
                            var chunkBytesReceived = 0L
                            var lastError: Exception? = null
                            while (attempt < 3) {
                                attempt++
                                try {
                                    raf.seek(chunkOffset)
                                    chunkBytesReceived = 0L
                                    val conn = (chunkUrl.openConnection() as HttpURLConnection).apply {
                                        connectTimeout = 12_000
                                        readTimeout = 25_000
                                        requestMethod = "GET"
                                    }
                                    val responseCode = conn.responseCode
                                    if (responseCode != 200) {
                                        conn.disconnect()
                                        throw IllegalStateException("HTTP $responseCode while fetching chunk $chunkIndex")
                                    }
                                    BufferedInputStream(conn.inputStream, 64 * 1024).use { input ->
                                        while (true) {
                                            val readCount = input.read(ioBuffer)
                                            if (readCount == -1) break
                                            raf.write(ioBuffer, 0, readCount)
                                            chunkBytesReceived += readCount
                                        }
                                    }
                                    conn.disconnect()
                                    lastError = null
                                    break
                                } catch (e: Exception) {
                                    lastError = e
                                    if (attempt < 3) delay(400L * attempt)
                                }
                            }
                            if (lastError != null) throw lastError

                            transferredForFile = chunkOffset + chunkBytesReceived
                            bytesDownloadedThisSession += chunkBytesReceived
                            val elapsedSec = max(0.005, (System.nanoTime() - fileStartNano) / 1_000_000_000.0)
                            val realSpeedBytesPerSec = bytesDownloadedThisSession.toDouble() / elapsedSec

                            val doneChunks = chunkIndex + 1
                            _uiState.update { state ->
                                val updatedFiles = state.files.map { f ->
                                    if (f.id != fileId) f
                                    else f.copy(
                                        completedChunks = doneChunks,
                                        transferredBytes = minOf(f.sizeBytes, transferredForFile),
                                        currentSpeedBytesPerSec = realSpeedBytesPerSec,
                                        status = FileTransferStatus.TRANSFERRING
                                    )
                                }
                                state.copy(
                                    files = updatedFiles,
                                    liveOverallSpeedBytesPerSec = realSpeedBytesPerSec,
                                    peakSpeedBytesPerSec = max(state.peakSpeedBytesPerSec, realSpeedBytesPerSec)
                                )
                            }
                        }
                        raf.fd.sync()
                    }

                    // Verify exact file size and SHA-256 integrity before marking COMPLETED
                    updateFileState(fileId) {
                        it.copy(status = FileTransferStatus.VERIFYING, currentSpeedBytesPerSec = 0.0)
                    }

                    val actualLength = tempPartFile.length()
                    if (actualLength != initialItem.sizeBytes) {
                        throw IllegalStateException("حجم الملف المستلم ($actualLength بايت) لا يطابق الحجم الأصلي (${initialItem.sizeBytes} بايت)")
                    }

                    val computedSha256 = Sha256Util.computeFileSha256(tempPartFile)
                    val expectedSha256 = initialItem.sha256Expected
                    val shaMatches = expectedSha256.isBlank() || computedSha256.equals(expectedSha256, ignoreCase = true)
                    if (!shaMatches) {
                        throw IllegalStateException("فشل التحقق من سلامة الملف (SHA-256 غير متطابق)")
                    }

                    if (finalOutFile.exists()) finalOutFile.delete()
                    val renamed = tempPartFile.renameTo(finalOutFile)
                    val savedFile = if (renamed) finalOutFile else tempPartFile

                    // Send ACK to sender
                    try {
                        val ackUrl = URL(
                            "http://$hostIp:$hostPort/api/ack?fileId=${URLEncoder.encode(initialItem.id, "UTF-8")}&verified=true&code=${URLEncoder.encode(sessionCode, "UTF-8")}"
                        )
                        (ackUrl.openConnection() as HttpURLConnection).apply {
                            connectTimeout = 3000
                            readTimeout = 3000
                            responseCode
                            disconnect()
                        }
                    } catch (_: Exception) {
                    }

                    val totalElapsedSec = max(0.005, (System.nanoTime() - fileStartNano) / 1_000_000_000.0)
                    val avgSpeed = bytesDownloadedThisSession.toDouble() / totalElapsedSec

                    var completedSnapshot: TransferFileItem? = null
                    updateFileState(fileId) { f ->
                        val done = f.copy(
                            completedChunks = totalChunks,
                            transferredBytes = f.sizeBytes,
                            currentSpeedBytesPerSec = 0.0,
                            status = FileTransferStatus.COMPLETED,
                            savedPath = savedFile.absolutePath,
                            sha256Actual = computedSha256,
                            sha256Verified = true,
                            errorMessage = null
                        )
                        completedSnapshot = done
                        done
                    }

                    completedSnapshot?.let {
                        recordHistoryItem(
                            item = it,
                            direction = TransferDirection.RECEIVING,
                            peerAddress = "$hostIp:$hostPort",
                            avgSpeedBytesPerSec = avgSpeed
                        )
                    }
                } catch (ce: CancellationException) {
                    if (tempPartFile.exists()) tempPartFile.delete()
                    updateFileState(fileId) {
                        it.copy(status = FileTransferStatus.CANCELLED, currentSpeedBytesPerSec = 0.0)
                    }
                    throw ce
                } catch (e: Exception) {
                    anyFailed = true
                    val errMsg = e.message ?: "انقطع الاتصال أثناء تحميل الدفعات"
                    updateFileState(fileId) { f ->
                        val failed = f.copy(
                            status = FileTransferStatus.FAILED,
                            currentSpeedBytesPerSec = 0.0,
                            errorMessage = errMsg
                        )
                        recordHistoryItem(
                            item = failed,
                            direction = TransferDirection.RECEIVING,
                            peerAddress = "$hostIp:$hostPort",
                            avgSpeedBytesPerSec = 0.0,
                            errorMessage = errMsg
                        )
                        failed
                    }
                    break
                }
            }

            withContext(Dispatchers.Main) {
                _uiState.update {
                    it.copy(
                        isTransferRunning = false,
                        liveOverallSpeedBytesPerSec = 0.0,
                        statusBannerMessage = if (anyFailed) {
                            "تعذر إكمال بعض الملفات بسبب انقطاع الاتصال. يمكنك الضغط على استئناف لإكمال الدفعات المتبقية."
                        } else {
                            "اكتمل استلام جميع الملفات والتحقق من سلامتها (SHA-256) وحفظها في (Downloads/BarqSher)!"
                        }
                    )
                }
                loadAllDeviceMediaAndFiles()
            }
        }
    }

    private fun resolveBarqSherDownloadsDir(appContext: Context): File {
        return try {
            @Suppress("DEPRECATION")
            val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            val barqDir = File(publicDownloads, "BarqSher")
            if (barqDir.exists() || barqDir.mkdirs()) {
                barqDir
            } else {
                File(
                    appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: appContext.filesDir,
                    "BarqSher"
                ).apply { mkdirs() }
            }
        } catch (_: Exception) {
            File(
                appContext.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: appContext.filesDir,
                "BarqSher"
            ).apply { mkdirs() }
        }
    }

    /**
     * Connects to a discovered peer session directly.
     */
    fun connectToDiscoveredPeer(peer: DiscoveredPeerSession) {
        connectAndReceiveFromInput("BARQP2P|${peer.sessionCode}|${peer.hostIp}|${peer.port}")
    }

    /**
     * Resolves the sender's IP, port, and session code from:
     * 1. QR payload: BARQP2P|code|ip|port
     * 2. Explicit IP & code: ip:port#code or ip#code
     * 3. Auto-discovered UDP peer matching the entered code
     * 4. Active UDP broadcast query (BARQ_FIND|code) + subnet scan across all local interfaces
     */
    fun connectAndReceiveFromInput(rawInput: String) {
        val cleaned = rawInput.trim()
        if (cleaned.isEmpty()) {
            _uiState.update {
                it.copy(
                    statusBannerMessage = "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد"
                )
            }
            return
        }

        _uiState.update { it.copy(isConnectingToSender = true, statusBannerMessage = null) }

        viewModelScope.launch(Dispatchers.IO) {
            val candidateEndpoints = mutableListOf<Pair<String, Int>>()
            val defaultPort = _uiState.value.networkStatus.port
            var sessionCode = ""

            if (cleaned.startsWith("BARQP2P|", ignoreCase = true)) {
                val tokens = cleaned.split("|")
                if (tokens.size >= 4) {
                    sessionCode = tokens[1].trim().uppercase(Locale.US)
                    val ip = tokens[2].trim()
                    val port = tokens[3].trim().toIntOrNull() ?: defaultPort
                    if (ip.isNotEmpty()) candidateEndpoints.add(ip to port)
                }
            } else if (cleaned.contains("#")) {
                // Format: 192.168.1.10:8989#BRQ-0110 or 192.168.1.10#0110
                val hostPart = cleaned.substringBefore("#").trim()
                val codePart = cleaned.substringAfter("#").trim().uppercase(Locale.US)
                sessionCode = if (codePart.startsWith("BRQ-") || codePart.startsWith("5G-")) codePart else "BRQ-$codePart"
                val ip = hostPart.substringBefore(":")
                val port = hostPart.substringAfter(":", "").toIntOrNull() ?: defaultPort
                if (ip.isNotEmpty()) candidateEndpoints.add(ip to port)
            } else {
                val normalizedCore = P2PChunkServer.normalizeCode(cleaned)
                if (normalizedCore.length == 4 && normalizedCore.all { it.isDigit() }) {
                    sessionCode = "BRQ-$normalizedCore"

                    // 1. Check already discovered UDP peers
                    _uiState.value.discoveredPeers.find {
                        P2PChunkServer.normalizeCode(it.sessionCode) == normalizedCore
                    }?.let { discovered ->
                        candidateEndpoints.add(discovered.hostIp to discovered.port)
                    }

                    // 2. Send a fast UDP BARQ_FIND query and wait 350ms for sender response
                    sendUdpFindQuery(sessionCode)
                    delay(350L)
                    _uiState.value.discoveredPeers.find {
                        P2PChunkServer.normalizeCode(it.sessionCode) == normalizedCore
                    }?.let { discovered ->
                        candidateEndpoints.add(discovered.hostIp to discovered.port)
                    }

                    // 3. Derive IP candidates from all active local interfaces + common hotspot gateways
                    val thirdOctet = normalizedCore.substring(0, 2).toIntOrNull()
                    val fourthOctet = normalizedCore.substring(2, 4).toIntOrNull()
                    if (thirdOctet != null && fourthOctet != null) {
                        val allIps = _uiState.value.networkStatus.allLocalIps
                        for (localIp in allIps) {
                            val parts = localIp.split(".")
                            if (parts.size == 4) {
                                candidateEndpoints.add("${parts[0]}.${parts[1]}.$thirdOctet.$fourthOctet" to defaultPort)
                                candidateEndpoints.add("${parts[0]}.${parts[1]}.${parts[2]}.$fourthOctet" to defaultPort)
                            }
                        }
                        candidateEndpoints.add("192.168.$thirdOctet.$fourthOctet" to 8989)
                    }
                }
            }

            val distinctEndpoints = candidateEndpoints.distinct()
            if (distinctEndpoints.isEmpty() || sessionCode.isBlank()) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(
                            isConnectingToSender = false,
                            showReceiveConfirmationDialog = false,
                            pendingIncomingFiles = emptyList(),
                            statusBannerMessage = "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد"
                        )
                    }
                }
                return@launch
            }

            var fetchedRemoteFiles: List<TransferFileItem>? = null
            var remoteChunkSize = _uiState.value.selectedChunkSize.bytes
            var resolvedIp = ""
            var resolvedPort = defaultPort

            for ((targetIp, targetPort) in distinctEndpoints) {
                try {
                    val encodedCode = URLEncoder.encode(sessionCode, "UTF-8")
                    val url = URL("http://$targetIp:$targetPort/api/manifest?code=$encodedCode")
                    val conn = (url.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 2500
                        readTimeout = 4000
                        requestMethod = "GET"
                    }
                    if (conn.responseCode == 200) {
                        val body = BufferedInputStream(conn.inputStream).bufferedReader().readText()
                        val json = JSONObject(body)
                        remoteChunkSize = json.optInt("chunkSize", remoteChunkSize)
                        val arr = json.optJSONArray("files")
                        if (arr != null && arr.length() > 0) {
                            val list = mutableListOf<TransferFileItem>()
                            for (i in 0 until arr.length()) {
                                val o = arr.getJSONObject(i)
                                val name = o.optString("name", "file_$i")
                                val size = o.optLong("sizeBytes", 0L)
                                val chunks = max(1, o.optInt("totalChunks", 1))
                                val sha256 = o.optString("sha256", "")
                                val splitWarn = o.optBoolean("hasSplitWarning", false)
                                if (size > 0L) {
                                    list.add(
                                        TransferFileItem(
                                            id = o.optString("id", "rem_$i"),
                                            name = name,
                                            sizeBytes = size,
                                            category = FileCategory.fromFileName(name),
                                            totalChunks = chunks,
                                            sha256Expected = sha256,
                                            hasSplitWarning = splitWarn
                                        )
                                    )
                                }
                            }
                            if (list.isNotEmpty()) {
                                fetchedRemoteFiles = list
                                resolvedIp = targetIp
                                resolvedPort = targetPort
                                conn.disconnect()
                                break
                            }
                        }
                    }
                    conn.disconnect()
                } catch (_: Exception) {
                }
            }

            withContext(Dispatchers.Main) {
                val validFiles = fetchedRemoteFiles
                if (validFiles.isNullOrEmpty()) {
                    _uiState.update {
                        it.copy(
                            isConnectingToSender = false,
                            showReceiveConfirmationDialog = false,
                            pendingIncomingFiles = emptyList(),
                            statusBannerMessage = "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد"
                        )
                    }
                } else {
                    _uiState.update { state ->
                        state.copy(
                            isConnectingToSender = false,
                            enteredReceiveCode = sessionCode,
                            remoteHostIp = resolvedIp,
                            remoteHostPort = resolvedPort,
                            remoteSessionCode = sessionCode,
                            remoteChunkSizeBytes = remoteChunkSize,
                            pendingIncomingFiles = validFiles,
                            showReceiveConfirmationDialog = true,
                            currentScreen = AppScreen.RECEIVE,
                            statusBannerMessage = null
                        )
                    }
                }
            }
        }
    }

    private fun sendUdpFindQuery(code: String) {
        try {
            DatagramSocket().use { ds ->
                ds.broadcast = true
                val bytes = "BARQ_FIND|$code".toByteArray(Charsets.UTF_8)
                val pkt = DatagramPacket(
                    bytes,
                    bytes.size,
                    InetAddress.getByName("255.255.255.255"),
                    P2PChunkServer.UDP_DISCOVERY_PORT
                )
                ds.send(pkt)
            }
        } catch (_: Exception) {
        }
    }

    fun confirmAndStartReceiving() {
        val incoming = _uiState.value.pendingIncomingFiles
        if (incoming.isEmpty()) {
            _uiState.update { it.copy(showReceiveConfirmationDialog = false) }
            return
        }
        _uiState.update { state ->
            state.copy(
                files = incoming,
                pendingIncomingFiles = emptyList(),
                showReceiveConfirmationDialog = false
            )
        }
        startLiveChunkedTransfer(TransferDirection.RECEIVING)
    }

    fun cancelReceiveConfirmation() {
        _uiState.update { state ->
            state.copy(
                pendingIncomingFiles = emptyList(),
                showReceiveConfirmationDialog = false,
                statusBannerMessage = "تم إلغاء استلام الملفات"
            )
        }
    }

    fun togglePauseResume() {
        _uiState.update { state ->
            val newPaused = !state.isPaused
            val updatedFiles = state.files.map { f ->
                if (f.status == FileTransferStatus.TRANSFERRING || f.status == FileTransferStatus.PAUSED) {
                    f.copy(status = if (newPaused) FileTransferStatus.PAUSED else FileTransferStatus.TRANSFERRING)
                } else f
            }
            state.copy(
                isPaused = newPaused,
                files = updatedFiles,
                statusBannerMessage = if (newPaused) "تم إيقاف النقل مؤقتاً مع حفظ موضع الدفعة الحالية" else "تم استئناف النقل المباشر من آخر دفعة (Chunk)"
            )
        }
    }

    fun exportSelfApkToDownloads() {
        viewModelScope.launch(Dispatchers.IO) {
            val appContext = getApplication<Application>()
            try {
                val sourceApk = File(appContext.applicationInfo.sourceDir)
                val outDir = resolveBarqSherDownloadsDir(appContext)
                val targetApk = File(outDir, "Barq-Sher.apk")
                sourceApk.inputStream().use { input ->
                    FileOutputStream(targetApk).use { output ->
                        input.copyTo(output, 64 * 1024)
                    }
                }
                val sizeMb = String.format(Locale.US, "%.1f MB", targetApk.length() / (1024.0 * 1024.0))
                withContext(Dispatchers.Main) {
                    _uiState.update { state ->
                        state.copy(
                            statusBannerMessage = "تم حفظ ملف التطبيق Barq-Sher.apk ($sizeMb) في التنزيلات، وعبر الرابط: http://${state.networkStatus.localIp}:${state.networkStatus.port}/barq-p2p.apk"
                        )
                    }
                }
            } catch (_: Exception) {
                withContext(Dispatchers.Main) {
                    _uiState.update {
                        it.copy(statusBannerMessage = "رابط تنزيل الـ APK جاهز: http://${it.networkStatus.localIp}:${it.networkStatus.port}/barq-p2p.apk")
                    }
                }
            }
        }
    }

    private fun recordHistoryItem(
        item: TransferFileItem,
        direction: TransferDirection,
        peerAddress: String,
        avgSpeedBytesPerSec: Double,
        errorMessage: String? = null
    ) {
        val record = TransferHistoryRecord(
            id = UUID.randomUUID().toString().take(10),
            fileName = item.name,
            sizeBytes = item.sizeBytes,
            category = item.category,
            direction = direction,
            status = item.status,
            timestampMillis = System.currentTimeMillis(),
            savedPath = item.savedPath,
            sha256Hash = item.sha256Actual.ifBlank { item.sha256Expected },
            sha256Verified = item.sha256Verified,
            averageSpeedBytesPerSec = avgSpeedBytesPerSec,
            peerAddress = peerAddress,
            errorMessage = errorMessage
        )
        _uiState.update { state ->
            val updated = (listOf(record) + state.transferHistory).take(100)
            savePersistedHistory(updated)
            state.copy(transferHistory = updated)
        }
    }

    fun clearTransferHistory() {
        _uiState.update { it.copy(transferHistory = emptyList()) }
        savePersistedHistory(emptyList())
    }

    private fun savePersistedHistory(records: List<TransferHistoryRecord>) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val arr = JSONArray()
                for (r in records) {
                    val o = JSONObject()
                    o.put("id", r.id)
                    o.put("fileName", r.fileName)
                    o.put("sizeBytes", r.sizeBytes)
                    o.put("category", r.category.name)
                    o.put("direction", r.direction.name)
                    o.put("status", r.status.name)
                    o.put("timestampMillis", r.timestampMillis)
                    o.put("savedPath", r.savedPath ?: "")
                    o.put("sha256Hash", r.sha256Hash)
                    o.put("sha256Verified", r.sha256Verified)
                    o.put("averageSpeedBytesPerSec", r.averageSpeedBytesPerSec)
                    o.put("peerAddress", r.peerAddress)
                    o.put("errorMessage", r.errorMessage ?: "")
                    arr.put(o)
                }
                val file = File(getApplication<Application>().filesDir, "barq_transfer_history.json")
                file.writeText(arr.toString())
            } catch (_: Exception) {
            }
        }
    }

    private fun loadPersistedHistory() {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val file = File(getApplication<Application>().filesDir, "barq_transfer_history.json")
                if (!file.exists()) return@launch
                val arr = JSONArray(file.readText())
                val list = mutableListOf<TransferHistoryRecord>()
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    list.add(
                        TransferHistoryRecord(
                            id = o.optString("id"),
                            fileName = o.optString("fileName"),
                            sizeBytes = o.optLong("sizeBytes"),
                            category = runCatching { FileCategory.valueOf(o.optString("category")) }.getOrDefault(FileCategory.DOCUMENT),
                            direction = runCatching { TransferDirection.valueOf(o.optString("direction")) }.getOrDefault(TransferDirection.RECEIVING),
                            status = runCatching { FileTransferStatus.valueOf(o.optString("status")) }.getOrDefault(FileTransferStatus.COMPLETED),
                            timestampMillis = o.optLong("timestampMillis"),
                            savedPath = o.optString("savedPath").ifBlank { null },
                            sha256Hash = o.optString("sha256Hash"),
                            sha256Verified = o.optBoolean("sha256Verified"),
                            averageSpeedBytesPerSec = o.optDouble("averageSpeedBytesPerSec", 0.0),
                            peerAddress = o.optString("peerAddress"),
                            errorMessage = o.optString("errorMessage").ifBlank { null }
                        )
                    )
                }
                withContext(Dispatchers.Main) {
                    _uiState.update { it.copy(transferHistory = list) }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun updateFileState(fileId: String, transform: (TransferFileItem) -> TransferFileItem) {
        _uiState.update { state ->
            state.copy(files = state.files.map { if (it.id == fileId) transform(it) else it })
        }
    }

    override fun onCleared() {
        super.onCleared()
        chunkServer?.stopServer()
    }
}
