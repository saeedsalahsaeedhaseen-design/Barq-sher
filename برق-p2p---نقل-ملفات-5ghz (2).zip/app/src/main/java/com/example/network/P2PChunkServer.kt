package com.example.network

import android.content.ContentResolver
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import com.example.model.ChunkSizeOption
import com.example.model.DiscoveredPeerSession
import com.example.model.HotspotNetworkStatus
import com.example.model.TransferFileItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStream
import java.io.RandomAccessFile
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.util.Collections

/**
 * Network-agnostic P2P HTTP Chunk Server & UDP Discovery Engine for "برق sher".
 * Works across any available network (Wi-Fi 2.4GHz, Wi-Fi 5GHz, Wi-Fi Hotspot, LAN,
 * or routable 3G/4G/5G/VPN connections) without requiring 5G or 5GHz.
 */
class P2PChunkServer(
    private val context: Context,
    private val scope: CoroutineScope,
    private val sessionCodeProvider: () -> String,
    private val isSenderReadyProvider: () -> Boolean,
    private val chunkSizeProvider: () -> ChunkSizeOption,
    private val filesProvider: () -> List<TransferFileItem>,
    private val onChunkServed: (fileId: String, chunkIndex: Int, bytesCount: Int) -> Unit,
    private val onPeerDiscovered: (DiscoveredPeerSession) -> Unit = {},
    private val onReceiverVerifiedFile: (fileId: String, verified: Boolean) -> Unit = { _, _ -> }
) {
    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private var udpListenerJob: Job? = null
    private var udpAnnounceJob: Job? = null
    private var udpSocket: DatagramSocket? = null

    var boundPort: Int = 8989
        private set

    fun startServer(): Int {
        if (serverJob?.isActive == true) return boundPort
        for (candidatePort in 8989..8999) {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress("0.0.0.0", candidatePort))
                serverSocket = ss
                boundPort = candidatePort
                break
            } catch (_: Exception) {
                // try next port in range 8989..8999
            }
        }
        val activeSocket = serverSocket ?: return boundPort
        serverJob = scope.launch(Dispatchers.IO) {
            while (isActive && !activeSocket.isClosed) {
                try {
                    val client = activeSocket.accept()
                    launch(Dispatchers.IO) {
                        handleClient(client)
                    }
                } catch (_: Exception) {
                    if (!isActive) break
                }
            }
        }
        startUdpDiscoveryEngine()
        return boundPort
    }

    private fun startUdpDiscoveryEngine() {
        if (udpListenerJob?.isActive == true) return
        udpListenerJob = scope.launch(Dispatchers.IO) {
            try {
                val ds = DatagramSocket(null).apply {
                    reuseAddress = true
                    broadcast = true
                    bind(InetSocketAddress(UDP_DISCOVERY_PORT))
                }
                udpSocket = ds
                val buf = ByteArray(2048)
                while (isActive && !ds.isClosed) {
                    val packet = DatagramPacket(buf, buf.size)
                    ds.receive(packet)
                    val msg = String(packet.data, 0, packet.length, StandardCharsets.UTF_8).trim()
                    val senderIp = packet.address?.hostAddress ?: continue
                    handleUdpMessage(msg, senderIp)
                }
            } catch (_: Exception) {
                // UDP discovery is an enhancement; direct code/QR/IP always works even if UDP port is busy
            }
        }

        udpAnnounceJob = scope.launch(Dispatchers.IO) {
            while (isActive) {
                try {
                    if (isSenderReadyProvider() && filesProvider().isNotEmpty()) {
                        broadcastSenderPresence()
                    }
                } catch (_: Exception) {
                }
                delay(2000L)
            }
        }
    }

    private fun handleUdpMessage(msg: String, packetSenderIp: String) {
        if (msg.startsWith("BARQ_ANNOUNCE|")) {
            // BARQ_ANNOUNCE|code|ip|port|deviceName|fileCount|totalBytes
            val parts = msg.split("|")
            if (parts.size >= 7) {
                val code = parts[1].trim()
                if (code.equals(sessionCodeProvider().trim(), ignoreCase = true) && isSenderReadyProvider()) {
                    return // Ignore own announce
                }
                val announcedIp = parts[2].trim().ifEmpty { packetSenderIp }
                val port = parts[3].toIntOrNull() ?: 8989
                val deviceName = parts[4].trim()
                val fileCount = parts[5].toIntOrNull() ?: 0
                val totalBytes = parts[6].toLongOrNull() ?: 0L
                onPeerDiscovered(
                    DiscoveredPeerSession(
                        sessionCode = code,
                        hostIp = if (announcedIp == "0.0.0.0" || announcedIp == "127.0.0.1") packetSenderIp else announcedIp,
                        port = port,
                        deviceName = deviceName,
                        fileCount = fileCount,
                        totalBytes = totalBytes,
                        lastSeenMillis = System.currentTimeMillis()
                    )
                )
            }
        } else if (msg.startsWith("BARQ_FIND|")) {
            val wantedCode = msg.substringAfter("BARQ_FIND|").trim()
            if (isSenderReadyProvider() && filesProvider().isNotEmpty() &&
                wantedCode.equals(sessionCodeProvider().trim(), ignoreCase = true)
            ) {
                broadcastSenderPresence(targetIp = packetSenderIp)
            }
        }
    }

    fun broadcastSenderPresence(targetIp: String? = null) {
        val files = filesProvider()
        if (!isSenderReadyProvider() || files.isEmpty()) return
        val net = inspectNetworkStatus(context, boundPort, true)
        val deviceModel = "${Build.MANUFACTURER} ${Build.MODEL}".trim().replace("|", " ")
        val totalBytes = files.sumOf { it.sizeBytes }
        val payload = "BARQ_ANNOUNCE|${sessionCodeProvider()}|${net.localIp}|$boundPort|$deviceModel|${files.size}|$totalBytes"
        val bytes = payload.toByteArray(StandardCharsets.UTF_8)

        try {
            DatagramSocket().use { senderSocket ->
                senderSocket.broadcast = true
                val targets = mutableSetOf<String>()
                if (!targetIp.isNullOrBlank()) {
                    targets.add(targetIp)
                } else {
                    targets.add("255.255.255.255")
                    net.allLocalIps.forEach { ip ->
                        val parts = ip.split(".")
                        if (parts.size == 4) {
                            targets.add("${parts[0]}.${parts[1]}.${parts[2]}.255")
                        }
                    }
                }
                for (dest in targets) {
                    try {
                        val addr = InetAddress.getByName(dest)
                        val pkt = DatagramPacket(bytes, bytes.size, addr, UDP_DISCOVERY_PORT)
                        senderSocket.send(pkt)
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    fun stopServer() {
        try {
            serverSocket?.close()
        } catch (_: Exception) {
        }
        try {
            udpSocket?.close()
        } catch (_: Exception) {
        }
        serverJob?.cancel()
        udpListenerJob?.cancel()
        udpAnnounceJob?.cancel()
    }

    private fun handleClient(socket: Socket) {
        socket.use { client ->
            client.soTimeout = 30_000
            val reader = BufferedReader(InputStreamReader(client.getInputStream(), StandardCharsets.UTF_8))
            val requestLine = reader.readLine() ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return
            val fullPath = parts[1]
            while (true) {
                val line = reader.readLine()
                if (line.isNullOrEmpty()) break
            }

            val out = BufferedOutputStream(client.getOutputStream(), 64 * 1024)
            when {
                fullPath == "/" || fullPath.startsWith("/index") -> {
                    val net = inspectNetworkStatus(context, boundPort, true)
                    val htmlBytes = PeerJsWebPortalHtml.buildHtml(
                        defaultCode = sessionCodeProvider(),
                        hostIp = net.localIp,
                        hostPort = boundPort
                    ).toByteArray(StandardCharsets.UTF_8)
                    writeHttpHeader(out, "200 OK", "text/html; charset=utf-8", htmlBytes.size.toLong())
                    out.write(htmlBytes)
                    out.flush()
                }

                fullPath.startsWith("/api/manifest") -> {
                    val query = fullPath.substringAfter("?", "")
                    val params = parseQueryParams(query)
                    val requestedCode = normalizeCode(params["code"] ?: "")
                    val activeCode = normalizeCode(sessionCodeProvider())
                    val files = filesProvider()
                    val senderReady = isSenderReadyProvider()

                    if (!senderReady || files.isEmpty() || requestedCode.isEmpty() || requestedCode != activeCode) {
                        val errJson = JSONObject().apply {
                            put("error", "فشل الربط: الرمز غير صحيح أو أن الطرف المرسل لم يبدأ عملية الإرسال بعد")
                        }.toString().toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "403 Forbidden", "application/json; charset=utf-8", errJson.size.toLong())
                        out.write(errJson)
                        out.flush()
                        return
                    }

                    val chunkBytes = chunkSizeProvider().bytes
                    val root = JSONObject()
                    root.put("sessionCode", sessionCodeProvider().trim())
                    root.put("chunkSize", chunkBytes)
                    root.put("senderDevice", "${Build.MANUFACTURER} ${Build.MODEL}".trim())
                    val arr = JSONArray()
                    for (f in files) {
                        val obj = JSONObject()
                        obj.put("id", f.id)
                        obj.put("name", f.name)
                        obj.put("sizeBytes", f.sizeBytes)
                        obj.put("category", f.category.name)
                        obj.put("totalChunks", maxOf(1, ((f.sizeBytes + chunkBytes - 1) / chunkBytes).toInt()))
                        obj.put("sha256", f.sha256Expected)
                        obj.put("hasSplitWarning", f.hasSplitWarning)
                        arr.put(obj)
                    }
                    root.put("files", arr)
                    val jsonBytes = root.toString().toByteArray(StandardCharsets.UTF_8)
                    writeHttpHeader(out, "200 OK", "application/json; charset=utf-8", jsonBytes.size.toLong())
                    out.write(jsonBytes)
                    out.flush()
                }

                fullPath.startsWith("/api/chunk") -> {
                    val query = fullPath.substringAfter("?", "")
                    val params = parseQueryParams(query)
                    val requestedCode = normalizeCode(params["code"] ?: "")
                    val activeCode = normalizeCode(sessionCodeProvider())
                    val senderReady = isSenderReadyProvider()

                    if (!senderReady || requestedCode.isEmpty() || requestedCode != activeCode) {
                        val err = "Forbidden: Invalid code or sender not ready".toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "403 Forbidden", "text/plain; charset=utf-8", err.size.toLong())
                        out.write(err)
                        out.flush()
                        return
                    }

                    val fileId = params["fileId"] ?: params["id"] ?: ""
                    val chunkIndex = params["chunkIndex"]?.toIntOrNull() ?: params["index"]?.toIntOrNull() ?: -1
                    val customChunkSize = params["chunkSize"]?.toIntOrNull()
                    val fileItem = filesProvider().find { it.id == fileId }
                    if (fileItem == null || chunkIndex < 0) {
                        val err = "File or chunk index not found".toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "404 Not Found", "text/plain; charset=utf-8", err.size.toLong())
                        out.write(err)
                        out.flush()
                        return
                    }

                    val chunkSize = if (customChunkSize != null && customChunkSize in (16 * 1024)..(4 * 1024 * 1024)) {
                        customChunkSize
                    } else {
                        chunkSizeProvider().bytes
                    }
                    val offset = chunkIndex.toLong() * chunkSize.toLong()
                    val remaining = (fileItem.sizeBytes - offset).coerceAtLeast(0L)
                    val bytesToRead = minOf(chunkSize.toLong(), remaining).toInt()

                    val buffer = readFileChunk(context.contentResolver, fileItem, offset, bytesToRead)
                    if (buffer == null) {
                        val err = "Failed to read file chunk from storage".toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "500 Internal Server Error", "text/plain; charset=utf-8", err.size.toLong())
                        out.write(err)
                        out.flush()
                        return
                    }

                    writeHttpHeader(out, "200 OK", "application/octet-stream", buffer.size.toLong())
                    out.write(buffer)
                    out.flush()
                    onChunkServed(fileItem.id, chunkIndex, buffer.size)
                }

                fullPath.startsWith("/api/ack") -> {
                    val query = fullPath.substringAfter("?", "")
                    val params = parseQueryParams(query)
                    val requestedCode = normalizeCode(params["code"] ?: "")
                    val activeCode = normalizeCode(sessionCodeProvider())
                    if (requestedCode.isNotEmpty() && requestedCode == activeCode) {
                        val fileId = params["fileId"] ?: ""
                        val verified = params["verified"] == "true"
                        onReceiverVerifiedFile(fileId, verified)
                    }
                    val ok = "{\"status\":\"ok\"}".toByteArray(StandardCharsets.UTF_8)
                    writeHttpHeader(out, "200 OK", "application/json; charset=utf-8", ok.size.toLong())
                    out.write(ok)
                    out.flush()
                }

                fullPath.startsWith("/barq-p2p.apk") || fullPath.startsWith("/download-apk") -> {
                    val apkFile = File(context.applicationInfo.sourceDir)
                    if (apkFile.exists()) {
                        val header = buildString {
                            append("HTTP/1.1 200 OK\r\n")
                            append("Content-Type: application/vnd.android.package-archive\r\n")
                            append("Content-Disposition: attachment; filename=\"Barq-Sher.apk\"\r\n")
                            append("Content-Length: ${apkFile.length()}\r\n")
                            append("Connection: close\r\n\r\n")
                        }
                        out.write(header.toByteArray(StandardCharsets.UTF_8))
                        FileInputStream(apkFile).use { fis ->
                            val buf = ByteArray(64 * 1024)
                            while (true) {
                                val r = fis.read(buf)
                                if (r == -1) break
                                out.write(buf, 0, r)
                            }
                        }
                        out.flush()
                    } else {
                        val err = "APK source not found".toByteArray(StandardCharsets.UTF_8)
                        writeHttpHeader(out, "404 Not Found", "text/plain", err.size.toLong())
                        out.write(err)
                        out.flush()
                    }
                }

                else -> {
                    val msg = "Barq Sher P2P Endpoint".toByteArray(StandardCharsets.UTF_8)
                    writeHttpHeader(out, "404 Not Found", "text/plain", msg.size.toLong())
                    out.write(msg)
                    out.flush()
                }
            }
        }
    }

    private fun writeHttpHeader(
        out: OutputStream,
        status: String,
        contentType: String,
        contentLength: Long
    ) {
        val header = buildString {
            append("HTTP/1.1 $status\r\n")
            append("Content-Type: $contentType\r\n")
            append("Content-Length: $contentLength\r\n")
            append("Access-Control-Allow-Origin: *\r\n")
            append("Cache-Control: no-store\r\n")
            append("Connection: close\r\n\r\n")
        }
        out.write(header.toByteArray(StandardCharsets.UTF_8))
    }

    private fun parseQueryParams(query: String): Map<String, String> {
        if (query.isBlank()) return emptyMap()
        return query.split("&").mapNotNull { pair ->
            val idx = pair.indexOf('=')
            if (idx <= 0) null
            else {
                val k = URLDecoder.decode(pair.substring(0, idx), "UTF-8")
                val v = URLDecoder.decode(pair.substring(idx + 1), "UTF-8")
                k to v
            }
        }.toMap()
    }

    companion object {
        const val UDP_DISCOVERY_PORT = 8988

        fun normalizeCode(raw: String): String {
            val trimmed = raw.trim().uppercase(Locale.US)
            if (trimmed.isEmpty()) return ""
            // Accept either "BRQ-1234", "5G-1234", or bare digits "1234" by comparing the core suffix/token
            return trimmed.removePrefix("BRQ-").removePrefix("5G-")
        }

        /**
         * Reads the exact full chunk of [length] bytes at [offset] from the user-selected [TransferFileItem]
         * using ContentResolver or RandomAccessFile without loading the entire file into memory.
         */
        fun readFileChunk(
            resolver: ContentResolver,
            item: TransferFileItem,
            offset: Long,
            length: Int
        ): ByteArray? {
            if (length < 0) return null
            if (length == 0) return ByteArray(0)

            val localFile = item.localFile
            if (localFile != null && localFile.exists()) {
                return try {
                    RandomAccessFile(localFile, "r").use { raf ->
                        if (offset >= raf.length()) return ByteArray(0)
                        raf.seek(offset)
                        val maxReadable = minOf(length.toLong(), raf.length() - offset).toInt()
                        val buf = ByteArray(maxReadable)
                        var totalRead = 0
                        while (totalRead < maxReadable) {
                            val r = raf.read(buf, totalRead, maxReadable - totalRead)
                            if (r == -1) break
                            totalRead += r
                        }
                        if (totalRead == buf.size) buf else buf.copyOf(totalRead)
                    }
                } catch (_: IOException) {
                    null
                }
            }

            val uri = item.uri ?: return null
            try {
                resolver.openFileDescriptor(uri, "r")?.use { pfd ->
                    FileInputStream(pfd.fileDescriptor).use { fis ->
                        val channel = fis.channel
                        channel.position(offset)
                        val buf = ByteArray(length)
                        val byteBuffer = ByteBuffer.wrap(buf)
                        var totalRead = 0
                        while (totalRead < length) {
                            val r = channel.read(byteBuffer)
                            if (r <= 0) break
                            totalRead += r
                        }
                        if (totalRead > 0) {
                            return if (totalRead == length) buf else buf.copyOf(totalRead)
                        }
                    }
                }
            } catch (_: Exception) {
            }

            return try {
                val input = resolver.openInputStream(uri) ?: return null
                input.use { stream ->
                    var remainingToSkip = offset
                    val skipScratch = ByteArray(minOf(64 * 1024L, maxOf(1L, remainingToSkip)).toInt())
                    while (remainingToSkip > 0) {
                        val skipped = stream.skip(remainingToSkip)
                        if (skipped > 0) {
                            remainingToSkip -= skipped
                        } else {
                            val toReadSkip = minOf(skipScratch.size.toLong(), remainingToSkip).toInt()
                            val readCount = stream.read(skipScratch, 0, toReadSkip)
                            if (readCount == -1) return ByteArray(0)
                            remainingToSkip -= readCount
                        }
                    }

                    val out = ByteArrayOutputStream(minOf(length, 64 * 1024))
                    val readBuf = ByteArray(minOf(length, 64 * 1024))
                    var totalRead = 0
                    while (totalRead < length) {
                        val toRead = minOf(readBuf.size, length - totalRead)
                        val r = stream.read(readBuf, 0, toRead)
                        if (r == -1) break
                        out.write(readBuf, 0, r)
                        totalRead += r
                    }
                    if (totalRead == 0) null else out.toByteArray()
                }
            } catch (_: Exception) {
                null
            }
        }

        /**
         * Network-agnostic inspection of all active interfaces (Wi-Fi 2.4GHz, Wi-Fi 5GHz, Hotspot,
         * Ethernet, VPN, or Mobile 3G/4G/5G). Never restricts or rejects any network type.
         */
        fun inspectNetworkStatus(
            context: Context,
            port: Int,
            isServerRunning: Boolean
        ): HotspotNetworkStatus {
            val discoveredIps = mutableListOf<String>()
            var preferredIp = "127.0.0.1"
            var ifaceName = "شبكة محلية"

            try {
                val interfaces = Collections.list(NetworkInterface.getNetworkInterfaces())
                for (ni in interfaces) {
                    if (!ni.isUp || ni.isLoopback) continue
                    val name = ni.name?.lowercase() ?: ""
                    val addrs = Collections.list(ni.inetAddresses)
                    for (addr in addrs) {
                        if (addr is Inet4Address && !addr.isLoopbackAddress) {
                            val ip = addr.hostAddress ?: continue
                            discoveredIps.add(ip)
                            // Prefer Wi-Fi / Hotspot / tether interfaces (wlan, ap, swlan, rndis)
                            val isWifiOrHotspot = name.contains("wlan") || name.contains("ap") ||
                                name.contains("swlan") || name.contains("rndis") || name.contains("eth")
                            if (preferredIp == "127.0.0.1" || isWifiOrHotspot || ip.startsWith("192.168.")) {
                                preferredIp = ip
                                ifaceName = ni.displayName ?: ni.name ?: "wlan0"
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            }

            if (discoveredIps.isEmpty()) {
                discoveredIps.add(preferredIp)
            }

            var freq = 0
            var linkSpeed = 0
            try {
                val wm = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
                @Suppress("DEPRECATION")
                val info = wm?.connectionInfo
                if (info != null) {
                    if (info.frequency > 0) freq = info.frequency
                    if (info.linkSpeed > 0) linkSpeed = info.linkSpeed
                }
            } catch (_: Exception) {
            }

            val is5G = freq >= 4900
            var netTypeLabel = when {
                freq >= 4900 -> "Wi-Fi (5GHz)"
                freq in 2400..2500 -> "Wi-Fi (2.4GHz)"
                preferredIp.startsWith("192.168.") || preferredIp.startsWith("172.") || preferredIp.startsWith("10.") ->
                    "شبكة محلية / نقطة اتصال متاحة"
                else -> "اتصال شبكة متاح"
            }

            try {
                val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
                val activeNet = cm?.activeNetwork
                val caps = if (activeNet != null) cm.getNetworkCapabilities(activeNet) else null
                if (caps != null) {
                    netTypeLabel = when {
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ->
                            if (is5G) "Wi-Fi (نطاق 5GHz)" else if (freq > 0) "Wi-Fi (نطاق 2.4GHz)" else "شبكة Wi-Fi متصلة"
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ->
                            "بيانات الجوال (3G / 4G / 5G) + نقطة اتصال"
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) ->
                            "شبكة محلية (Ethernet)"
                        else -> netTypeLabel
                    }
                }
            } catch (_: Exception) {
            }

            return HotspotNetworkStatus(
                localIp = preferredIp,
                allLocalIps = discoveredIps.distinct(),
                port = port,
                is5GHzBand = is5G,
                frequencyMHz = freq,
                linkSpeedMbps = linkSpeed,
                ssidOrInterface = ifaceName,
                networkTypeLabel = netTypeLabel,
                isServerRunning = isServerRunning
            )
        }
    }
}
